# How to Get Your EduTrack APK via GitHub Actions
## (No Android Studio needed — everything builds in the cloud)

---

## What happens:
You upload the code to GitHub → GitHub's servers build the APK for free → You download it.

---

## STEP 1 — Create a GitHub account (if you don't have one)
1. Go to https://github.com
2. Click "Sign up" → enter email, password, username
3. Verify your email

---

## STEP 2 — Create a new repository
1. After login, click the **"+"** icon (top right) → **"New repository"**
2. Repository name: `EduTrack`
3. Set to **Public** (required for free Actions minutes)
4. Click **"Create repository"**

---

## STEP 3 — Upload the project files
On the repository page, click **"uploading an existing file"** link.

**Drag and drop** the entire contents of the EduTrack folder:
- All `.js` files and folders (`src/`, `android/`, etc.)
- `package.json`, `App.js`, `index.js`, `babel.config.js`, `metro.config.js`, `app.json`
- The `.github/` folder (this contains the build workflow)

Click **"Commit changes"** at the bottom.

> ⚠️ Make sure the `.github/workflows/build-apk.yml` file is included — this is what triggers the build.

---

## STEP 4 — Watch the build run
1. Click the **"Actions"** tab on your repository
2. You'll see **"Build EduTrack APK"** running (yellow circle = in progress)
3. Wait ~10–15 minutes for it to complete
4. Green checkmark ✅ = success | Red ✗ = something went wrong

---

## STEP 5 — Download your APK
1. Click on the completed workflow run
2. Scroll down to the **"Artifacts"** section
3. Click **"EduTrack-debug-apk"** → it downloads as a ZIP
4. Extract the ZIP → you get `app-debug.apk`

---

## STEP 6 — Install on your Android phone
1. Transfer `app-debug.apk` to your phone (WhatsApp, email, USB, Google Drive)
2. On your phone: **Settings → Security → Unknown sources → Allow**
3. Open the APK file → tap Install
4. Open EduTrack → tap "🎓 Student Demo" to try it immediately!

---

## Optional: Add Firebase (for real accounts across devices)

If you want real user accounts that sync across devices:

1. Go to https://console.firebase.google.com → Create project "EduTrack"
2. Add Android app → package name: `com.edutrack.app`
3. Download `google-services.json`
4. In GitHub repo → **Settings → Secrets → Actions → New repository secret**
   - Name: `GOOGLE_SERVICES_JSON`
   - Value: paste the entire contents of your `google-services.json` file
5. Re-run the workflow → APK will have Firebase enabled

Without this step, the app works perfectly in **Demo Mode** (local storage only).

---

## If the build fails:

**Common fixes:**
- Make sure `.github/workflows/build-apk.yml` was uploaded
- Make sure `android/app/google-services.json` was uploaded
- Go to Actions tab → click the failed run → click the failed step → read the error

**Re-trigger a build manually:**
Actions tab → "Build EduTrack APK" → "Run workflow" button (right side)

---

## That's it! 🎉

Total time: ~20 minutes (most of it is GitHub building in background).
You get a real Android APK you can install on any Android phone.
