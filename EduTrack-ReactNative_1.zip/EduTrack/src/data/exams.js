// src/data/exams.js
export const EXAM_CATEGORIES = [
  'All', 'Civil Services', 'SSC', 'Banking', 'Railways',
  'Defence', 'Engineering', 'Medical', 'Law', 'Management',
  'Teaching', 'State Services', 'Insurance', 'Judiciary', 'School', 'College',
];

export const EXAM_DB = {
  'UPSC CSE': {
    category: 'Civil Services', org: 'UPSC', badge: 'hot',
    fullName: 'UPSC Civil Services Examination', targetHours: 1000,
    subjects: {
      'General Studies I': ['Ancient History of India', 'Medieval History of India', 'Modern History (1757–1947)', 'Indian National Movement', 'Post-Independence India', 'Indian Society & Diversity', 'Role of Women & Urbanisation', 'Globalization & Effects', 'World Geography', 'Physical Geography of India', 'Indian Climate, Rivers & Natural Vegetation', 'Economic Geography', 'Disaster & Disaster Management'],
      'General Studies II (Polity)': ['Historical Background of Constitution', 'Making of the Constitution', 'Salient Features of Constitution', 'Preamble', 'Union & Its Territory', 'Citizenship', 'Fundamental Rights (Art 12–35)', 'Directive Principles of State Policy', 'Fundamental Duties', 'Amendment of Constitution', 'Basic Structure Doctrine', 'Parliament — Lok Sabha & Rajya Sabha', 'President & Vice President', 'Prime Minister & Council of Ministers', 'Judiciary — Supreme Court & High Courts', 'Federalism — Centre–State Relations', 'Local Self Government', 'Constitutional & Statutory Bodies', 'Government Schemes & Policies', 'Social Justice', 'International Relations & Bodies'],
      'General Studies III': ['Indian Economy — Overview', 'Planning & NITI Aayog', 'Agriculture & Food Security', 'Land Reforms', 'Industry & Infrastructure', 'Money, Banking & Capital Markets', 'Fiscal Policy & Budget', 'External Sector — Trade & BoP', 'Science & Technology', 'Space & Nuclear Programme', 'IT & Biotechnology', 'Environment & Ecology', 'Biodiversity & Conservation', 'Climate Change & International Conventions', 'Disaster Risk Reduction', 'Internal Security & Extremism'],
      'General Studies IV (Ethics)': ['Ethics & Human Interface', 'Attitude & Aptitude', 'Emotional Intelligence', 'Moral Thinkers', 'Civil Service Values', 'Probity in Governance', 'Case Studies in Ethics'],
      'CSAT (Paper II)': ['Reading Comprehension', 'Interpersonal Skills', 'Logical Reasoning & Analytical Ability', 'Decision Making', 'General Mental Ability', 'Basic Numeracy', 'Data Interpretation'],
      'Essay & Optional': ['Essay Writing — Paper I', 'Essay Writing — Paper II', 'Optional Subject — Paper I', 'Optional Subject — Paper II'],
    },
  },
  'SSC CGL': {
    category: 'SSC', org: 'Staff Selection Commission', badge: 'hot',
    fullName: 'Combined Graduate Level Examination', targetHours: 600,
    subjects: {
      'Quantitative Aptitude': ['Number System', 'Percentage', 'Ratio & Proportion', 'Profit & Loss', 'Simple & Compound Interest', 'Time & Work', 'Time, Speed & Distance', 'Data Interpretation', 'Algebra', 'Geometry & Mensuration', 'Trigonometry', 'Statistics'],
      'English Language': ['Reading Comprehension', 'Cloze Test', 'Para Jumbles', 'Error Spotting', 'Sentence Improvement', 'Fill in the Blanks', 'Synonyms & Antonyms', 'Idioms & Phrases'],
      'General Awareness': ['History of India', 'Indian Geography', 'Indian Polity', 'Indian Economy', 'General Science', 'Computer & Technology', 'Current Affairs'],
      'Reasoning': ['Analogy', 'Classification', 'Series', 'Coding-Decoding', 'Blood Relations', 'Direction Sense', 'Syllogism', 'Non-Verbal Reasoning', 'Matrix & Miscellaneous'],
    },
  },
  'SSC CHSL': {
    category: 'SSC', org: 'Staff Selection Commission', badge: 'pop',
    fullName: 'Combined Higher Secondary Level Exam', targetHours: 400,
    subjects: {
      'Quantitative Aptitude': ['Arithmetic', 'Algebra', 'Geometry', 'Trigonometry', 'Statistics & Data Interpretation'],
      'English Language': ['Vocabulary', 'Grammar', 'Reading Comprehension', 'Writing Ability'],
      'General Awareness': ['Current Affairs', 'Static GK', 'Science & Technology'],
      'Reasoning': ['Verbal Reasoning', 'Non-Verbal Reasoning', 'Logical Ability'],
    },
  },
  'SBI PO': {
    category: 'Banking', org: 'State Bank of India', badge: 'hot',
    fullName: 'SBI Probationary Officer Exam', targetHours: 700,
    subjects: {
      'Quantitative Aptitude': ['Number Series', 'Simplification', 'Quadratic Equations', 'Data Interpretation', 'Percentage & Ratio', 'Profit & Loss', 'Time & Work', 'Probability'],
      'Reasoning Ability': ['Puzzle & Seating Arrangement', 'Syllogism', 'Input-Output', 'Coding-Decoding', 'Inequalities', 'Blood Relations', 'Critical Reasoning'],
      'English Language': ['Reading Comprehension', 'Cloze Test', 'Para Jumbles', 'Error Detection', 'Sentence Correction', 'Vocabulary'],
      'General Awareness': ['Banking & Financial Awareness', 'Current Affairs', 'Static GK', 'RBI Policies', 'Government Schemes'],
      'Computer Aptitude': ['History of Computers', 'Hardware & Software', 'MS Office', 'Internet & Networking', 'Cybersecurity Basics'],
    },
  },
  'IBPS PO': {
    category: 'Banking', org: 'IBPS', badge: 'pop',
    fullName: 'IBPS Probationary Officer Exam', targetHours: 700,
    subjects: {
      'Quantitative Aptitude': ['Number System', 'DI', 'Algebra', 'Arithmetic Chapters'],
      'Reasoning': ['Puzzles', 'Coding-Decoding', 'Syllogism', 'Miscellaneous'],
      'English Language': ['Reading Comprehension', 'Grammar', 'Vocabulary'],
      'General Awareness': ['Banking Awareness', 'Current Affairs', 'Static GK'],
      'Computer Knowledge': ['Basics of Computers', 'MS Office', 'Internet'],
    },
  },
  'RBI Grade B': {
    category: 'Banking', org: 'Reserve Bank of India', badge: 'hot',
    fullName: 'RBI Grade B Officer Exam', targetHours: 800,
    subjects: {
      'General Awareness': ['Indian Economy', 'Banking & Finance', 'Current Affairs', 'Social Issues'],
      'English': ['Writing Skills', 'Reading Comprehension', 'Grammar'],
      'Quantitative Aptitude': ['DI & DS', 'Arithmetic', 'Algebra'],
      'Reasoning': ['Logical Reasoning', 'Analytical Skills'],
      'Economic & Social Issues': ['Indian Economy', 'Monetary Policy', 'Social Development'],
    },
  },
  'RRB NTPC': {
    category: 'Railways', org: 'Railway Recruitment Board', badge: 'hot',
    fullName: 'Non-Technical Popular Categories', targetHours: 500,
    subjects: {
      'Mathematics': ['Number System', 'Decimal & Fractions', 'LCM & HCF', 'Ratio & Proportion', 'Percentage', 'Mensuration', 'Time & Work', 'Time & Distance', 'Simple & Compound Interest', 'Profit & Loss', 'Algebra', 'Geometry', 'Statistics'],
      'Reasoning': ['Analogies', 'Series', 'Coding & Decoding', 'Mathematical Operations', 'Similarities & Differences', 'Relationships', 'Analytical Reasoning', 'Blood Relations'],
      'General Awareness': ['Current Events', 'Games & Sports', 'Art & Culture', 'Indian Literature', 'General Science', 'Science & Technology', 'Environment', 'Indian Polity', 'Geography', 'Indian Economy'],
    },
  },
  'NDA': {
    category: 'Defence', org: 'UPSC', badge: 'pop',
    fullName: 'National Defence Academy & Naval Academy Exam', targetHours: 600,
    subjects: {
      'Mathematics': ['Algebra', 'Matrices & Determinants', 'Trigonometry', 'Analytical Geometry', 'Differential Calculus', 'Integral Calculus', 'Vector Algebra', 'Statistics & Probability'],
      'General Ability — English': ['Grammar & Usage', 'Vocabulary', 'Comprehension', 'Cohesion'],
      'General Ability — GK': ['Physics', 'Chemistry', 'General Science', 'Social Studies', 'Geography', 'Current Events'],
    },
  },
  'CDS': {
    category: 'Defence', org: 'UPSC',
    fullName: 'Combined Defence Services Exam', targetHours: 500,
    subjects: {
      'English': ['Grammar', 'Vocabulary', 'Comprehension', 'Usage'],
      'General Knowledge': ['Current Affairs', 'History', 'Geography', 'Economics', 'Polity', 'Physics & Chemistry'],
      'Elementary Mathematics': ['Arithmetic', 'Algebra', 'Trigonometry', 'Geometry', 'Mensuration', 'Statistics'],
    },
  },
  'AFCAT': {
    category: 'Defence', org: 'Indian Air Force',
    fullName: 'Air Force Common Admission Test', targetHours: 400,
    subjects: {
      'General Awareness': ['History', 'Sports', 'Geography', 'Environment', 'Civics', 'Defence', 'Art', 'Current Affairs'],
      'Verbal Ability': ['Comprehension', 'Vocabulary & Grammar', 'Analogies', 'Error Detection'],
      'Numerical Ability': ['Arithmetic', 'Algebra', 'DI'],
      'Reasoning & Military Aptitude': ['Spatial Ability', 'Mechanical Aptitude', 'Verbal & Non-Verbal Reasoning'],
    },
  },
  'JEE Main': {
    category: 'Engineering', org: 'NTA', badge: 'hot',
    fullName: 'Joint Entrance Examination — Main', targetHours: 1000,
    subjects: {
      'Physics': ['Kinematics', 'Laws of Motion', 'Work, Energy & Power', 'Rotational Motion', 'Gravitation', 'Thermal Properties', 'Thermodynamics', 'Kinetic Theory', 'Oscillations & Waves', 'Electrostatics', 'Current Electricity', 'Magnetic Effects', 'Electromagnetic Induction', 'Alternating Current', 'EM Waves', 'Ray Optics', 'Wave Optics', 'Dual Nature', 'Atoms & Nuclei', 'Semiconductor Devices'],
      'Chemistry': ['Basic Concepts of Chemistry', 'Structure of Atom', 'Chemical Bonding', 'States of Matter', 'Thermodynamics', 'Equilibrium', 'Redox Reactions', 'Organic Chemistry Basics', 'Hydrocarbons', 'Solid State', 'Solutions', 'Electrochemistry', 'Chemical Kinetics', 'Surface Chemistry', 'Metallurgy', 'Coordination Compounds', 'Haloalkanes', 'Alcohols, Phenols, Ethers', 'Aldehydes & Ketones', 'Amines', 'Biomolecules & Polymers'],
      'Mathematics': ['Sets, Relations & Functions', 'Complex Numbers', 'Matrices & Determinants', 'Permutations & Combinations', 'Binomial Theorem', 'Sequences & Series', 'Straight Lines', 'Circles', 'Conic Sections', '3D Geometry', 'Vectors', 'Differential Equations', 'Limits & Continuity', 'Differentiation', 'Integration', 'Statistics & Probability', 'Trigonometry'],
    },
  },
  'NEET UG': {
    category: 'Medical', org: 'NTA', badge: 'hot',
    fullName: 'National Eligibility cum Entrance Test (UG)', targetHours: 1000,
    subjects: {
      'Physics': ['Physical World & Measurement', 'Kinematics', 'Laws of Motion', 'Work, Energy & Power', 'Motion of System of Particles', 'Gravitation', 'Properties of Bulk Matter', 'Thermodynamics', 'Oscillations & Waves', 'Electrostatics', 'Current Electricity', 'Magnetic Effects', 'Electromagnetic Waves', 'Optics', 'Dual Nature', 'Atoms & Nuclei', 'Electronic Devices'],
      'Chemistry': ['Some Basic Concepts', 'Structure of Atom', 'Classification of Elements', 'Chemical Bonding', 'States of Matter', 'Thermodynamics', 'Equilibrium', 'Redox Reactions', 'Hydrogen', 's-Block Elements', 'Some p-Block Elements', 'Organic Chemistry', 'Hydrocarbons', 'Solid State', 'Solutions', 'Electrochemistry', 'Chemical Kinetics', 'Surface Chemistry', 'p-Block (Higher)', 'd & f Block', 'Coordination Compounds', 'Biomolecules', 'Polymers'],
      'Biology — Botany': ['Living World', 'Biological Classification', 'Plant Kingdom', 'Morphology of Plants', 'Anatomy of Plants', 'Cell Structure', 'Cell Division', 'Transport in Plants', 'Mineral Nutrition', 'Photosynthesis', 'Respiration in Plants', 'Plant Growth', 'Reproduction in Plants'],
      'Biology — Zoology': ['Animal Kingdom', 'Structural Organisation in Animals', 'Human Physiology — Digestion', 'Human Physiology — Breathing', 'Human Physiology — Excretion', 'Human Physiology — Locomotion', 'Human Physiology — Neural Control', 'Human Reproduction', 'Reproductive Health', 'Principles of Inheritance', 'Evolution', 'Human Health & Disease', 'Biotechnology', 'Ecosystem', 'Biodiversity & Conservation'],
    },
  },
  'CAT': {
    category: 'Management', org: 'IIMs', badge: 'hot',
    fullName: 'Common Admission Test', targetHours: 800,
    subjects: {
      'Verbal Ability & RC': ['Reading Comprehension', 'Para Jumbles', 'Para Summary', 'Odd One Out', 'Sentence Completion', 'Grammar & Usage'],
      'Data Interpretation & LR': ['Tables & Charts', 'Bar & Line Graphs', 'Pie Charts', 'Caselets', 'Puzzles', 'Seating Arrangements', 'Blood Relations', 'Syllogisms', 'Binary Logic'],
      'Quantitative Aptitude': ['Number System', 'Percentage', 'Ratio & Proportion', 'Profit & Loss', 'Time & Work', 'Time, Speed & Distance', 'Algebra', 'Geometry & Mensuration', 'Modern Maths', 'Logarithm & Surds'],
    },
  },
  'CLAT': {
    category: 'Law', org: 'Consortium of NLUs', badge: 'pop',
    fullName: 'Common Law Admission Test', targetHours: 600,
    subjects: {
      'English Language': ['Reading Comprehension', 'Vocabulary in Context', 'Grammar & Usage'],
      'Current Affairs & GK': ['Current Affairs', 'Static GK', 'Legal GK'],
      'Legal Reasoning': ['Legal Principles Application', 'Legal Maxims', 'Constitutional Law Basics', 'Torts & Contracts Basics'],
      'Logical Reasoning': ['Argument Analysis', 'Inference Drawing', 'Logical Puzzles', 'Critical Reasoning'],
      'Quantitative Techniques': ['Basic Arithmetic', 'DI', 'Percentage & Ratio'],
    },
  },
  'CTET': {
    category: 'Teaching', org: 'CBSE', badge: 'pop',
    fullName: 'Central Teacher Eligibility Test', targetHours: 400,
    subjects: {
      'Child Development & Pedagogy': ['Development of Child', 'Concept of Inclusive Education', 'Learning & Pedagogy'],
      'Language I': ['Language Comprehension', 'Pedagogy of Language Development'],
      'Language II': ['Comprehension', 'Pedagogy of Language'],
      'Mathematics': ['Content — Class 1–8', 'Pedagogical Issues'],
      'Environmental Studies / Science': ['Content Knowledge', 'Pedagogy'],
    },
  },
  'GATE': {
    category: 'Engineering', org: 'IITs / IISc', badge: 'pop',
    fullName: 'Graduate Aptitude Test in Engineering', targetHours: 800,
    subjects: {
      'Engineering Mathematics': ['Linear Algebra', 'Calculus', 'Differential Equations', 'Complex Variables', 'Probability & Statistics', 'Numerical Methods'],
      'General Aptitude': ['Verbal Ability', 'Numerical Ability'],
      'Core Engineering Subject': ['Branch-specific Core Topics — Refer official syllabus for your branch'],
    },
  },
  'State PSC': {
    category: 'State Services', org: 'State PSCs',
    fullName: 'State Public Service Commission Exam', targetHours: 800,
    subjects: {
      'General Studies I': ['History of India & Freedom Struggle', 'Geography of India & World', 'Indian Economy & Development', 'Indian Polity & Governance'],
      'General Studies II': ['Science & Technology', 'Environment & Ecology', 'Current Affairs', 'Disaster Management'],
      'State-specific Paper': ['State History & Culture', 'State Geography', 'State Economy & Schemes', 'Regional Language Literature'],
      'CSAT': ['Reading Comprehension', 'Logical Reasoning', 'Analytical Ability', 'Basic Numeracy'],
    },
  },
  'LIC AAO': {
    category: 'Insurance', org: 'Life Insurance Corporation',
    fullName: 'LIC Assistant Administrative Officer', targetHours: 500,
    subjects: {
      'Reasoning': ['Puzzles', 'Syllogism', 'Coding-Decoding', 'Blood Relations', 'Directions'],
      'Quantitative Aptitude': ['DI', 'Arithmetic', 'Number System'],
      'General Knowledge': ['Banking & Insurance Awareness', 'Current Events', 'Static GK'],
      'English Language': ['Reading Comprehension', 'Grammar', 'Vocabulary'],
      'Insurance Awareness': ['Types of Insurance', 'LIC Products', 'IRDAI Regulations', 'Financial Markets'],
    },
  },
  'Judicial Services': {
    category: 'Judiciary', org: 'State High Courts',
    fullName: 'State Judicial Services Exam', targetHours: 900,
    subjects: {
      'Law of Evidence': ['Indian Evidence Act 1872', 'Relevancy of Facts', 'Documentary Evidence', 'Oral Evidence', 'Burden of Proof'],
      'Code of Civil Procedure': ['Jurisdiction', 'Pleadings', 'Suits', 'Appeals', 'Execution'],
      'Code of Criminal Procedure': ['FIR & Investigation', 'Trial', 'Bail & Bonds', 'Appeals & Revisions'],
      'Indian Penal Code': ['General Exceptions', 'Offences Against State', 'Offences Against Body & Property', 'Offences Against Women'],
      'Constitutional Law': ['Fundamental Rights', 'Directive Principles', 'Federal Structure', 'Emergency Provisions'],
      'Contract & Civil Laws': ['Formation of Contracts', 'Performance & Discharge', 'Breach & Remedies', 'Specific Relief Act', 'Transfer of Property Act'],
    },
  },
  'Class 10 Board': {
    category: 'School', org: 'CBSE / State Boards',
    fullName: 'Class 10 Board Examinations', targetHours: 400,
    subjects: {
      'Mathematics': ['Real Numbers', 'Polynomials', 'Linear Equations', 'Quadratic Equations', 'Arithmetic Progressions', 'Triangles', 'Coordinate Geometry', 'Trigonometry', 'Circles', 'Surface Areas & Volumes', 'Statistics', 'Probability'],
      'Science': ['Chemical Reactions', 'Acids, Bases & Salts', 'Metals & Non-metals', 'Carbon Compounds', 'Life Processes', 'Control & Coordination', 'Reproduction', 'Heredity & Evolution', 'Light', 'Electricity', 'Magnetic Effects', 'Energy Sources', 'Environment'],
      'Social Science': ['Nationalism in India', 'Industrialisation', 'Urbanisation', 'Print Culture', 'Resources & Development', 'Water Resources', 'Agriculture', 'Minerals & Energy', 'Manufacturing', 'Democratic Politics', 'Federalism', 'Political Parties', 'Money & Credit', 'Globalisation', 'Consumer Rights'],
      'English': ['Reading Comprehension', 'Writing Skills', 'Grammar', 'Literature — First Flight', 'Literature — Footprints Without Feet'],
    },
  },
  'Class 12 Board': {
    category: 'School', org: 'CBSE / State Boards',
    fullName: 'Class 12 Board Examinations', targetHours: 500,
    subjects: {
      'Physics': ['Electrostatics', 'Current Electricity', 'Magnetic Effects', 'Electromagnetic Induction', 'AC Circuits', 'EM Waves', 'Optics', 'Dual Nature', 'Atoms & Nuclei', 'Semiconductor Devices'],
      'Chemistry': ['Solid State', 'Solutions', 'Electrochemistry', 'Chemical Kinetics', 'Surface Chemistry', 'p-Block Elements', 'd & f Block', 'Coordination Compounds', 'Haloalkanes', 'Alcohols & Phenols', 'Aldehydes & Ketones', 'Amines', 'Biomolecules', 'Polymers'],
      'Mathematics': ['Relations & Functions', 'Inverse Trigonometry', 'Matrices', 'Determinants', 'Continuity & Differentiability', 'Applications of Derivatives', 'Integrals', 'Differential Equations', 'Vectors', '3D Geometry', 'Linear Programming', 'Probability'],
      'Biology': ['Reproduction', 'Genetics', 'Evolution', 'Human Health', 'Biotechnology', 'Ecology'],
      'English': ['Flamingo — Prose', 'Flamingo — Poetry', 'Vistas — Supplementary', 'Writing Skills'],
    },
  },
  'College Semester': {
    category: 'College', org: 'University',
    fullName: 'Undergraduate Semester Examinations', targetHours: 300,
    subjects: {
      'Core Subject 1': ['Unit 1 — Fundamentals', 'Unit 2 — Core Concepts', 'Unit 3 — Applications', 'Unit 4 — Advanced Topics', 'Unit 5 — Case Studies'],
      'Core Subject 2': ['Unit 1 — Theory', 'Unit 2 — Principles', 'Unit 3 — Methods', 'Unit 4 — Practice', 'Unit 5 — Review'],
      'Elective': ['Elective Topic 1', 'Elective Topic 2', 'Elective Topic 3'],
      'Language & Communication': ['Technical Writing', 'Presentation Skills', 'Professional Communication'],
    },
  },
};
