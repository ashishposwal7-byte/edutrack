// src/utils/theme.js
export const Colors = {
  bg: '#0D0F14',
  surface: '#141820',
  card: '#1B2130',
  border: '#252D3D',
  accent: '#4F8EF7',
  accent2: '#7C5CFC',
  green: '#34D399',
  amber: '#FBBF24',
  red: '#F87171',
  pink: '#F472B6',
  text: '#E8EDF5',
  muted: '#7A8499',
  white: '#FFFFFF',
};

export const Gradients = {
  accent: ['#4F8EF7', '#7C5CFC'],
  green: ['#34D399', '#059669'],
  amber: ['#FBBF24', '#F59E0B'],
  red: ['#F87171', '#EF4444'],
  dark: ['#0D0F14', '#1B2130'],
  hero: ['#0f1a35', '#120a2e'],
};

export const Spacing = {
  xs: 4, sm: 8, md: 12, lg: 16, xl: 20, xxl: 24, xxxl: 32,
};

export const Radius = {
  sm: 8, md: 12, lg: 16, xl: 20, full: 999,
};

export const FontSize = {
  xs: 11, sm: 13, md: 15, lg: 17, xl: 20, xxl: 24, xxxl: 32,
};

export const Shadows = {
  card: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 8,
  },
  hero: {
    shadowColor: '#4F8EF7',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.3,
    shadowRadius: 20,
    elevation: 12,
  },
};
