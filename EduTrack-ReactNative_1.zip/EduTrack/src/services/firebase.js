// src/services/firebase.js
// ─────────────────────────────────────────────
// IMPORTANT: Replace with your Firebase config
// Get it from: Firebase Console → Project Settings → Your Apps → Web App
// ─────────────────────────────────────────────
import auth from '@react-native-firebase/auth';
import firestore from '@react-native-firebase/firestore';

// Collections
export const COLLECTIONS = {
  USERS: 'users',
  TOPICS: 'topics',
  SESSIONS: 'sessions',
  SCORES: 'scores',
  TASKS: 'tasks',
  ASSIGNMENTS: 'assignments',
  MESSAGES: 'messages',
  NOTIFICATIONS: 'notifications',
};

// ── AUTH ──────────────────────────────────────
export const signUp = async (email, password, name, role, subject) => {
  const cred = await auth().createUserWithEmailAndPassword(email, password);
  await cred.user.updateProfile({ displayName: name });
  await firestore().collection(COLLECTIONS.USERS).doc(cred.user.uid).set({
    uid: cred.user.uid,
    name,
    email,
    role,
    subject,
    examKey: null,
    target: 20,
    streak: 0,
    bestStreak: 0,
    createdAt: firestore.FieldValue.serverTimestamp(),
  });
  return cred.user;
};

export const signIn = (email, password) =>
  auth().signInWithEmailAndPassword(email, password);

export const signOut = () => auth().signOut();

export const getCurrentUser = () => auth().currentUser;

export const onAuthStateChanged = (callback) =>
  auth().onAuthStateChanged(callback);

// ── USER ──────────────────────────────────────
export const getUser = (uid) =>
  firestore().collection(COLLECTIONS.USERS).doc(uid).get();

export const updateUser = (uid, data) =>
  firestore().collection(COLLECTIONS.USERS).doc(uid).update(data);

export const onUserSnapshot = (uid, callback) =>
  firestore().collection(COLLECTIONS.USERS).doc(uid).onSnapshot(callback);

// ── TOPICS ────────────────────────────────────
export const getTopics = (uid) =>
  firestore().collection(COLLECTIONS.TOPICS).where('uid', '==', uid).get();

export const addTopic = (uid, topic) =>
  firestore().collection(COLLECTIONS.TOPICS).add({ ...topic, uid, createdAt: firestore.FieldValue.serverTimestamp() });

export const updateTopic = (id, data) =>
  firestore().collection(COLLECTIONS.TOPICS).doc(id).update(data);

export const deleteTopic = (id) =>
  firestore().collection(COLLECTIONS.TOPICS).doc(id).delete();

export const onTopicsSnapshot = (uid, callback) =>
  firestore().collection(COLLECTIONS.TOPICS).where('uid', '==', uid).onSnapshot(callback);

// ── SESSIONS ──────────────────────────────────
export const addSession = (uid, session) =>
  firestore().collection(COLLECTIONS.SESSIONS).add({ ...session, uid, createdAt: firestore.FieldValue.serverTimestamp() });

export const onSessionsSnapshot = (uid, callback) =>
  firestore().collection(COLLECTIONS.SESSIONS).where('uid', '==', uid).onSnapshot(callback);

// ── SCORES ────────────────────────────────────
export const addScore = (uid, score) =>
  firestore().collection(COLLECTIONS.SCORES).add({ ...score, uid, createdAt: firestore.FieldValue.serverTimestamp() });

export const onScoresSnapshot = (uid, callback) =>
  firestore().collection(COLLECTIONS.SCORES).where('uid', '==', uid).onSnapshot(callback);

// ── TASKS ─────────────────────────────────────
export const addTask = (uid, task) =>
  firestore().collection(COLLECTIONS.TASKS).add({ ...task, uid, createdAt: firestore.FieldValue.serverTimestamp() });

export const updateTask = (id, data) =>
  firestore().collection(COLLECTIONS.TASKS).doc(id).update(data);

export const onTasksSnapshot = (uid, callback) =>
  firestore().collection(COLLECTIONS.TASKS).where('uid', '==', uid).onSnapshot(callback);

// ── ASSIGNMENTS ───────────────────────────────
export const addAssignment = (assignment) =>
  firestore().collection(COLLECTIONS.ASSIGNMENTS).add({ ...assignment, createdAt: firestore.FieldValue.serverTimestamp() });

export const updateAssignment = (id, data) =>
  firestore().collection(COLLECTIONS.ASSIGNMENTS).doc(id).update(data);

export const onAssignmentsSnapshot = (uid, callback) =>
  firestore().collection(COLLECTIONS.ASSIGNMENTS).where('toUid', 'in', [uid, 'all']).onSnapshot(callback);

export const onSentAssignmentsSnapshot = (fromUid, callback) =>
  firestore().collection(COLLECTIONS.ASSIGNMENTS).where('fromUid', '==', fromUid).onSnapshot(callback);

// ── CHAT ──────────────────────────────────────
export const sendMessage = (chatId, message) =>
  firestore().collection(COLLECTIONS.MESSAGES).doc(chatId).collection('msgs').add({
    ...message,
    createdAt: firestore.FieldValue.serverTimestamp(),
  });

export const onMessagesSnapshot = (chatId, callback) =>
  firestore().collection(COLLECTIONS.MESSAGES).doc(chatId).collection('msgs')
    .orderBy('createdAt', 'asc').onSnapshot(callback);

export const getChatId = (uid1, uid2) => [uid1, uid2].sort().join('_');

// ── TEACHER: GET ALL STUDENTS ─────────────────
export const getStudents = () =>
  firestore().collection(COLLECTIONS.USERS).where('role', '==', 'student').get();

export const onStudentsSnapshot = (callback) =>
  firestore().collection(COLLECTIONS.USERS).where('role', '==', 'student').onSnapshot(callback);

export const getStudentTopics = (uid) =>
  firestore().collection(COLLECTIONS.TOPICS).where('uid', '==', uid).get();

export const getStudentSessions = (uid) =>
  firestore().collection(COLLECTIONS.SESSIONS).where('uid', '==', uid).get();

export const getStudentScores = (uid) =>
  firestore().collection(COLLECTIONS.SCORES).where('uid', '==', uid).get();
