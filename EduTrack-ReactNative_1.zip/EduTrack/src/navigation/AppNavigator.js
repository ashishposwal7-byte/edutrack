// src/navigation/AppNavigator.js
import React from 'react';
import { View, Text, ActivityIndicator, StyleSheet } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createDrawerNavigator } from '@react-navigation/drawer';
import { useAuth } from '../context/AuthContext';
import { Colors } from '../utils/theme';

// ── SCREENS ───────────────────────────────────
import LoginScreen from '../screens/auth/LoginScreen';
import SignUpScreen from '../screens/auth/SignUpScreen';
import ExamSelectorScreen from '../screens/auth/ExamSelectorScreen';

// Student screens
import DashboardScreen from '../screens/student/DashboardScreen';
import TasksScreen from '../screens/student/TasksScreen';
import SyllabusScreen from '../screens/student/SyllabusScreen';
import ExamSyllabusScreen from '../screens/student/ExamSyllabusScreen';
import ProgressScreen from '../screens/student/ProgressScreen';
import ScoresScreen from '../screens/student/ScoresScreen';
import StreakScreen from '../screens/student/StreakScreen';
import KiloScreen from '../screens/student/KiloScreen';
import TimerScreen from '../screens/student/TimerScreen';
import PlannerScreen from '../screens/student/PlannerScreen';
import AssignmentsScreen from '../screens/student/AssignmentsScreen';
import ResourcesScreen from '../screens/student/ResourcesScreen';
import ScheduleScreen from '../screens/student/ScheduleScreen';
import ChatScreen from '../screens/chat/ChatScreen';
import ConversationScreen from '../screens/chat/ConversationScreen';

// Teacher screens
import TeacherDashboardScreen from '../screens/teacher/TeacherDashboardScreen';
import StudentsScreen from '../screens/teacher/StudentsScreen';
import StudentDetailScreen from '../screens/teacher/StudentDetailScreen';
import ClassProgressScreen from '../screens/teacher/ClassProgressScreen';
import AssignTaskScreen from '../screens/teacher/AssignTaskScreen';

// Shared
import ProfileScreen from '../screens/shared/ProfileScreen';
import NotificationsScreen from '../screens/shared/NotificationsScreen';

const Stack = createNativeStackNavigator();
const Tab = createBottomTabNavigator();
const Drawer = createDrawerNavigator();

// ── TAB ICON ──────────────────────────────────
const TabIcon = ({ label, focused }) => (
  <View style={{ alignItems: 'center' }}>
    <Text style={{ fontSize: 18, opacity: focused ? 1 : 0.5 }}>
      {label}
    </Text>
  </View>
);

// ── STUDENT BOTTOM TABS ───────────────────────
const StudentTabs = () => (
  <Tab.Navigator
    screenOptions={{
      headerShown: false,
      tabBarStyle: {
        backgroundColor: Colors.surface,
        borderTopColor: Colors.border,
        height: 60,
        paddingBottom: 8,
      },
      tabBarActiveTintColor: Colors.accent,
      tabBarInactiveTintColor: Colors.muted,
      tabBarLabelStyle: { fontSize: 10, fontWeight: '600' },
    }}
  >
    <Tab.Screen name="Dashboard" component={DashboardScreen} options={{ tabBarIcon: ({ focused }) => <TabIcon label="🏠" focused={focused} /> }} />
    <Tab.Screen name="Study" component={TimerScreen} options={{ tabBarIcon: ({ focused }) => <TabIcon label="⏱️" focused={focused} /> }} />
    <Tab.Screen name="Planner" component={PlannerScreen} options={{ tabBarIcon: ({ focused }) => <TabIcon label="🤖" focused={focused} /> }} />
    <Tab.Screen name="Progress" component={ProgressScreen} options={{ tabBarIcon: ({ focused }) => <TabIcon label="📈" focused={focused} /> }} />
    <Tab.Screen name="More" component={StudentDrawer} options={{ tabBarIcon: ({ focused }) => <TabIcon label="☰" focused={focused} /> }} />
  </Tab.Navigator>
);

// ── STUDENT DRAWER ────────────────────────────
const StudentDrawer = () => (
  <Drawer.Navigator
    screenOptions={{
      headerStyle: { backgroundColor: Colors.surface },
      headerTintColor: Colors.text,
      drawerStyle: { backgroundColor: Colors.surface },
      drawerActiveTintColor: Colors.accent,
      drawerInactiveTintColor: Colors.muted,
      drawerLabelStyle: { fontWeight: '600' },
    }}
  >
    <Drawer.Screen name="Tasks" component={TasksScreen} options={{ drawerIcon: () => <Text>✅</Text> }} />
    <Drawer.Screen name="Exam Syllabus" component={ExamSyllabusScreen} options={{ drawerIcon: () => <Text>🎯</Text> }} />
    <Drawer.Screen name="1000-Hour Tracker" component={KiloScreen} options={{ drawerIcon: () => <Text>⚡</Text> }} />
    <Drawer.Screen name="Test Scores" component={ScoresScreen} options={{ drawerIcon: () => <Text>🏆</Text> }} />
    <Drawer.Screen name="Streak" component={StreakScreen} options={{ drawerIcon: () => <Text>🔥</Text> }} />
    <Drawer.Screen name="Schedule" component={ScheduleScreen} options={{ drawerIcon: () => <Text>📅</Text> }} />
    <Drawer.Screen name="Assignments" component={AssignmentsScreen} options={{ drawerIcon: () => <Text>📌</Text> }} />
    <Drawer.Screen name="Messages" component={ChatScreen} options={{ drawerIcon: () => <Text>💬</Text> }} />
    <Drawer.Screen name="Resources" component={ResourcesScreen} options={{ drawerIcon: () => <Text>🎥</Text> }} />
    <Drawer.Screen name="Notifications" component={NotificationsScreen} options={{ drawerIcon: () => <Text>🔔</Text> }} />
    <Drawer.Screen name="Profile" component={ProfileScreen} options={{ drawerIcon: () => <Text>👤</Text> }} />
  </Drawer.Navigator>
);

// ── TEACHER BOTTOM TABS ───────────────────────
const TeacherTabs = () => (
  <Tab.Navigator
    screenOptions={{
      headerShown: false,
      tabBarStyle: { backgroundColor: Colors.surface, borderTopColor: Colors.border, height: 60, paddingBottom: 8 },
      tabBarActiveTintColor: Colors.accent2,
      tabBarInactiveTintColor: Colors.muted,
      tabBarLabelStyle: { fontSize: 10, fontWeight: '600' },
    }}
  >
    <Tab.Screen name="Overview" component={TeacherDashboardScreen} options={{ tabBarIcon: ({ focused }) => <TabIcon label="🏠" focused={focused} /> }} />
    <Tab.Screen name="Students" component={StudentsScreen} options={{ tabBarIcon: ({ focused }) => <TabIcon label="👥" focused={focused} /> }} />
    <Tab.Screen name="Assign" component={AssignTaskScreen} options={{ tabBarIcon: ({ focused }) => <TabIcon label="📌" focused={focused} /> }} />
    <Tab.Screen name="Messages" component={ChatScreen} options={{ tabBarIcon: ({ focused }) => <TabIcon label="💬" focused={focused} /> }} />
    <Tab.Screen name="Profile" component={ProfileScreen} options={{ tabBarIcon: ({ focused }) => <TabIcon label="👤" focused={focused} /> }} />
  </Tab.Navigator>
);

// ── MAIN NAVIGATOR ────────────────────────────
export default function AppNavigator() {
  const { user, profile, loading } = useAuth();

  if (loading) {
    return (
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: Colors.bg }}>
        <Text style={{ fontSize: 40, marginBottom: 20 }}>📚</Text>
        <ActivityIndicator size="large" color={Colors.accent} />
        <Text style={{ color: Colors.muted, marginTop: 12, fontSize: 14 }}>Loading EduTrack...</Text>
      </View>
    );
  }

  return (
    <NavigationContainer theme={{ colors: { background: Colors.bg } }}>
      <Stack.Navigator screenOptions={{ headerShown: false }}>
        {!user ? (
          // Auth screens
          <>
            <Stack.Screen name="Login" component={LoginScreen} />
            <Stack.Screen name="SignUp" component={SignUpScreen} />
            <Stack.Screen name="ExamSelector" component={ExamSelectorScreen} />
          </>
        ) : !profile?.examKey && profile?.role === 'student' ? (
          // First time — choose exam
          <Stack.Screen name="ExamSelector" component={ExamSelectorScreen} />
        ) : profile?.role === 'teacher' ? (
          // Teacher app
          <>
            <Stack.Screen name="TeacherApp" component={TeacherTabs} />
            <Stack.Screen name="StudentDetail" component={StudentDetailScreen} options={{ headerShown: true, headerStyle: { backgroundColor: Colors.surface }, headerTintColor: Colors.text, title: 'Student Detail' }} />
            <Stack.Screen name="ClassProgress" component={ClassProgressScreen} options={{ headerShown: true, headerStyle: { backgroundColor: Colors.surface }, headerTintColor: Colors.text, title: 'Class Progress' }} />
            <Stack.Screen name="Conversation" component={ConversationScreen} options={{ headerShown: true, headerStyle: { backgroundColor: Colors.surface }, headerTintColor: Colors.text }} />
          </>
        ) : (
          // Student app
          <>
            <Stack.Screen name="StudentApp" component={StudentTabs} />
            <Stack.Screen name="Conversation" component={ConversationScreen} options={{ headerShown: true, headerStyle: { backgroundColor: Colors.surface }, headerTintColor: Colors.text }} />
          </>
        )}
      </Stack.Navigator>
    </NavigationContainer>
  );
}
