// src/context/DataContext.js
import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useAuth } from './AuthContext';
import * as FB from '../services/firebase';

const DataContext = createContext(null);

const localGet = async (key) => {
  try { const v = await AsyncStorage.getItem(key); return v ? JSON.parse(v) : []; } catch { return []; }
};
const localSet = async (key, val) => {
  try { await AsyncStorage.setItem(key, JSON.stringify(val)); } catch {}
};

export const DataProvider = ({ children }) => {
  const { user, profile, demoMode } = useAuth();
  const uid = user?.uid;

  const [topics, setTopics] = useState([]);
  const [sessions, setSessions] = useState([]);
  const [scores, setScores] = useState([]);
  const [tasks, setTasks] = useState([]);
  const [assignments, setAssignments] = useState([]);
  const [messages, setMessages] = useState({});
  const [students, setStudents] = useState([]);

  // ── LOAD DATA ──────────────────────────────
  useEffect(() => {
    if (!uid) return;
    if (demoMode) { loadDemoData(); return; }

    // Firebase real-time listeners
    const unsubTopics = FB.onTopicsSnapshot(uid, snap => {
      const data = snap.docs.map(d => ({ id: d.id, ...d.data() }));
      setTopics(data);
      localSet('topics_' + uid, data);
    });
    const unsubSessions = FB.onSessionsSnapshot(uid, snap => {
      const data = snap.docs.map(d => ({ id: d.id, ...d.data() }));
      setSessions(data.sort((a, b) => (b.createdAt?.seconds || 0) - (a.createdAt?.seconds || 0)));
      localSet('sessions_' + uid, data);
    });
    const unsubScores = FB.onScoresSnapshot(uid, snap => {
      const data = snap.docs.map(d => ({ id: d.id, ...d.data() }));
      setScores(data);
      localSet('scores_' + uid, data);
    });
    const unsubTasks = FB.onTasksSnapshot(uid, snap => {
      const data = snap.docs.map(d => ({ id: d.id, ...d.data() }));
      setTasks(data);
      localSet('tasks_' + uid, data);
    });
    const unsubAssign = FB.onAssignmentsSnapshot(uid, snap => {
      const data = snap.docs.map(d => ({ id: d.id, ...d.data() }));
      setAssignments(data);
    });
    // Teacher: load students
    if (profile?.role === 'teacher') {
      FB.onStudentsSnapshot(snap => {
        setStudents(snap.docs.map(d => ({ id: d.id, ...d.data() })));
      });
    }
    return () => { unsubTopics(); unsubSessions(); unsubScores(); unsubTasks(); unsubAssign(); };
  }, [uid, demoMode]);

  const loadDemoData = async () => {
    const t = await localGet('topics_' + uid);
    const s = await localGet('sessions_' + uid);
    const sc = await localGet('scores_' + uid);
    const tk = await localGet('tasks_' + uid);
    const as = await localGet('assignments_' + uid);

    if (t.length) { setTopics(t); } else {
      const demo = getDemoTopics();
      setTopics(demo); localSet('topics_' + uid, demo);
    }
    if (s.length) { setSessions(s); } else {
      const demo = getDemoSessions();
      setSessions(demo); localSet('sessions_' + uid, demo);
    }
    if (sc.length) { setScores(sc); } else {
      const demo = getDemoScores();
      setScores(demo); localSet('scores_' + uid, demo);
    }
    if (tk.length) { setTasks(tk); } else {
      const demo = getDemoTasks();
      setTasks(demo); localSet('tasks_' + uid, demo);
    }
    if (as.length) { setAssignments(as); } else {
      const demo = getDemoAssignments();
      setAssignments(demo); localSet('assignments_' + uid, demo);
    }
  };

  // ── TOPIC ACTIONS ──────────────────────────
  const addTopic = useCallback(async (topic) => {
    const newTopic = { ...topic, uid, id: 't' + Date.now(), status: topic.status || 'pending' };
    if (demoMode) {
      const updated = [...topics, newTopic];
      setTopics(updated); await localSet('topics_' + uid, updated);
    } else {
      await FB.addTopic(uid, topic);
    }
  }, [uid, demoMode, topics]);

  const updateTopicStatus = useCallback(async (id, status) => {
    const updated = topics.map(t => t.id === id ? { ...t, status } : t);
    setTopics(updated);
    if (demoMode) { await localSet('topics_' + uid, updated); }
    else { await FB.updateTopic(id, { status }); }
  }, [uid, demoMode, topics]);

  const deleteTopic = useCallback(async (id) => {
    const updated = topics.filter(t => t.id !== id);
    setTopics(updated);
    if (demoMode) { await localSet('topics_' + uid, updated); }
    else { await FB.deleteTopic(id); }
  }, [uid, demoMode, topics]);

  // ── SESSION ACTIONS ────────────────────────
  const addSession = useCallback(async (mins, label = 'Study Session') => {
    const session = { uid, mins, label, date: Date.now(), id: 's' + Date.now() };
    const updated = [session, ...sessions];
    setSessions(updated);
    if (demoMode) { await localSet('sessions_' + uid, updated); }
    else { await FB.addSession(uid, { mins, label, date: Date.now() }); }
    return session;
  }, [uid, demoMode, sessions]);

  // ── SCORE ACTIONS ──────────────────────────
  const addScore = useCallback(async (score) => {
    const newScore = { ...score, uid, id: 'sc' + Date.now(), date: Date.now() };
    const updated = [...scores, newScore];
    setScores(updated);
    if (demoMode) { await localSet('scores_' + uid, updated); }
    else { await FB.addScore(uid, score); }
  }, [uid, demoMode, scores]);

  // ── TASK ACTIONS ───────────────────────────
  const addTask = useCallback(async (task) => {
    const newTask = { ...task, uid, id: 'tk' + Date.now(), done: false };
    const updated = [...tasks, newTask];
    setTasks(updated);
    if (demoMode) { await localSet('tasks_' + uid, updated); }
    else { await FB.addTask(uid, task); }
  }, [uid, demoMode, tasks]);

  const toggleTask = useCallback(async (id) => {
    const updated = tasks.map(t => t.id === id ? { ...t, done: !t.done } : t);
    setTasks(updated);
    if (demoMode) { await localSet('tasks_' + uid, updated); }
    else { const t = tasks.find(x => x.id === id); await FB.updateTask(id, { done: !t?.done }); }
  }, [uid, demoMode, tasks]);

  // ── ASSIGNMENT ACTIONS ─────────────────────
  const completeAssignment = useCallback(async (id) => {
    const updated = assignments.map(a => a.id === id ? { ...a, done: true } : a);
    setAssignments(updated);
    if (demoMode) { await localSet('assignments_' + uid, updated); }
    else { await FB.updateAssignment(id, { done: true }); }
  }, [uid, demoMode, assignments]);

  const createAssignment = useCallback(async (assignment) => {
    const newA = { ...assignment, fromUid: uid, id: 'as' + Date.now(), done: false, createdAt: Date.now() };
    if (demoMode) {
      const updated = [...assignments, newA];
      setAssignments(updated);
      await localSet('assignments_' + uid, updated);
    } else {
      await FB.addAssignment(assignment);
    }
  }, [uid, demoMode, assignments]);

  // ── CHAT ───────────────────────────────────
  const loadMessages = useCallback(async (otherUid) => {
    if (demoMode) {
      const key = 'chat_' + [uid, otherUid].sort().join('_');
      const msgs = await localGet(key);
      setMessages(prev => ({ ...prev, [otherUid]: msgs }));
      return;
    }
    const chatId = FB.getChatId(uid, otherUid);
    FB.onMessagesSnapshot(chatId, snap => {
      const msgs = snap.docs.map(d => ({ id: d.id, ...d.data() }));
      setMessages(prev => ({ ...prev, [otherUid]: msgs }));
    });
  }, [uid, demoMode]);

  const sendMessage = useCallback(async (otherUid, text, type = 'text', extra = {}) => {
    const msg = { from: uid, text, type, ...extra, time: Date.now(), id: 'm' + Date.now() };
    const key = 'chat_' + [uid, otherUid].sort().join('_');
    if (demoMode) {
      const existing = await localGet(key);
      const updated = [...existing, msg];
      await localSet(key, updated);
      setMessages(prev => ({ ...prev, [otherUid]: updated }));
    } else {
      const chatId = FB.getChatId(uid, otherUid);
      await FB.sendMessage(chatId, { from: uid, text, type, ...extra });
    }
  }, [uid, demoMode]);

  // ── COMPUTED ───────────────────────────────
  const totalStudyMins = sessions.reduce((a, s) => a + (s.mins || 0), 0);
  const totalStudyHours = parseFloat((totalStudyMins / 60).toFixed(1));
  const kilo_pct = Math.min(100, (totalStudyHours / 1000) * 100);

  const today = new Date(); today.setHours(0, 0, 0, 0);
  const todayStr = today.toISOString().split('T')[0];
  const weekStart = today.getTime() - 6 * 86400000;
  const weekSessions = sessions.filter(s => (s.date || 0) >= weekStart);
  const weekMins = weekSessions.reduce((a, s) => a + (s.mins || 0), 0);
  const weekHours = parseFloat((weekMins / 60).toFixed(1));

  const topicsDone = topics.filter(t => t.status === 'done').length;
  const topicsTotal = topics.length;
  const topicsPct = topicsTotal ? Math.round(topicsDone / topicsTotal * 100) : 0;

  const avgScore = scores.length ? Math.round(scores.reduce((a, s) => a + s.score, 0) / scores.length) : null;
  const todayTasks = tasks.filter(t => t.date === todayStr);
  const pendingTasks = todayTasks.filter(t => !t.done).length;
  const pendingAssignments = assignments.filter(a => !a.done).length;

  return (
    <DataContext.Provider value={{
      // Data
      topics, sessions, scores, tasks, assignments, messages, students,
      // Actions
      addTopic, updateTopicStatus, deleteTopic,
      addSession, addScore,
      addTask, toggleTask,
      completeAssignment, createAssignment,
      loadMessages, sendMessage,
      // Computed
      totalStudyMins, totalStudyHours, kilo_pct,
      weekHours, weekMins, weekSessions,
      topicsDone, topicsTotal, topicsPct,
      avgScore, todayTasks, pendingTasks, pendingAssignments,
      todayStr,
    }}>
      {children}
    </DataContext.Provider>
  );
};

export const useData = () => useContext(DataContext);

// ── DEMO DATA ──────────────────────────────────
const getDemoTopics = () => [
  { id: 'tp1', subject: 'Polity', name: 'Historical Background', status: 'done', examKey: 'UPSC CSE' },
  { id: 'tp2', subject: 'Polity', name: 'Making of the Constitution', status: 'done', examKey: 'UPSC CSE' },
  { id: 'tp3', subject: 'Polity', name: 'Salient Features', status: 'done', examKey: 'UPSC CSE' },
  { id: 'tp4', subject: 'Polity', name: 'Preamble', status: 'done', examKey: 'UPSC CSE' },
  { id: 'tp5', subject: 'Polity', name: 'Fundamental Rights (Art 12–35)', status: 'inprogress', examKey: 'UPSC CSE' },
  { id: 'tp6', subject: 'Polity', name: 'Directive Principles', status: 'pending', examKey: 'UPSC CSE' },
  { id: 'tp7', subject: 'History', name: '1857 Revolt', status: 'done', examKey: 'UPSC CSE' },
  { id: 'tp8', subject: 'History', name: 'INC Formation', status: 'inprogress', examKey: 'UPSC CSE' },
  { id: 'tp9', subject: 'History', name: 'Non-Cooperation Movement', status: 'pending', examKey: 'UPSC CSE' },
  { id: 'tp10', subject: 'Geography', name: 'Indian Ocean Currents', status: 'inprogress', examKey: 'UPSC CSE' },
  { id: 'tp11', subject: 'Geography', name: 'Monsoon System', status: 'pending', examKey: 'UPSC CSE' },
  { id: 'tp12', subject: 'Economy', name: 'Basic Macro Concepts', status: 'pending', examKey: 'UPSC CSE' },
];

const getDemoSessions = () => {
  const today = new Date(); today.setHours(0, 0, 0, 0);
  const d = today.getTime();
  return [
    { id: 'ss1', date: d - 6 * 86400000, mins: 120, label: 'Polity — Ch 1-3' },
    { id: 'ss2', date: d - 5 * 86400000, mins: 90, label: 'History — 1857' },
    { id: 'ss3', date: d - 4 * 86400000, mins: 150, label: 'Polity + Geography' },
    { id: 'ss4', date: d - 3 * 86400000, mins: 60, label: 'Economy basics' },
    { id: 'ss5', date: d - 2 * 86400000, mins: 180, label: 'Polity revision' },
    { id: 'ss6', date: d - 86400000, mins: 120, label: 'History deep dive' },
    { id: 'ss7', date: d, mins: 45, label: 'Geography — Ocean' },
  ];
};

const getDemoScores = () => [
  { id: 'sc1', name: 'Mock Test #1', subject: 'Full Mock Test', score: 62, max: 100, time: 120, rank: 342, notes: 'Polity strong, Economy weak', date: Date.now() - 15 * 86400000 },
  { id: 'sc2', name: 'Polity Quiz', subject: 'Polity', score: 78, max: 100, time: 45, rank: null, notes: '', date: Date.now() - 10 * 86400000 },
  { id: 'sc3', name: 'Mock Test #2', subject: 'Full Mock Test', score: 71, max: 100, time: 120, rank: 215, notes: 'Improved in Polity', date: Date.now() - 5 * 86400000 },
];

const getDemoTasks = () => {
  const today = new Date().toISOString().split('T')[0];
  return [
    { id: 'tk1', title: 'Read Laxmikant Ch. 7', subject: 'Polity', date: today, priority: 'high', done: true },
    { id: 'tk2', title: 'Watch Mrunal History Ep. 12', subject: 'History', date: today, priority: 'medium', done: false },
    { id: 'tk3', title: 'Solve 50 MCQs — Polity', subject: 'Polity', date: today, priority: 'medium', done: false },
  ];
};

const getDemoAssignments = () => [
  { id: 'as1', title: 'Complete Polity Ch. 7–10', desc: 'Focus on Fundamental Rights.', due: '2026-06-25', priority: 'high', from: 'Prof. Sharma', done: false, createdAt: Date.now() - 2 * 86400000 },
  { id: 'as2', title: 'Watch Economy playlist', desc: 'Mrunal Economy Ep. 1–5', due: '2026-06-27', priority: 'medium', from: 'Prof. Sharma', done: false, createdAt: Date.now() - 86400000 },
];
