// src/context/AuthContext.js
import React, { createContext, useContext, useState, useEffect } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { onAuthStateChanged, getUser, signOut as fbSignOut } from '../services/firebase';

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);
  const [demoMode, setDemoMode] = useState(false);

  useEffect(() => {
    // Check for demo mode first
    AsyncStorage.getItem('demoUser').then(data => {
      if (data) {
        const u = JSON.parse(data);
        setUser(u);
        setProfile(u);
        setDemoMode(true);
        setLoading(false);
      }
    });

    // Firebase auth listener
    const unsub = onAuthStateChanged(async (fbUser) => {
      if (fbUser) {
        try {
          const doc = await getUser(fbUser.uid);
          const profileData = doc.data();
          setUser(fbUser);
          setProfile(profileData);
          setDemoMode(false);
          await AsyncStorage.setItem('cachedProfile', JSON.stringify(profileData));
        } catch (e) {
          // Offline — use cached
          const cached = await AsyncStorage.getItem('cachedProfile');
          if (cached) setProfile(JSON.parse(cached));
        }
        setLoading(false);
      } else {
        // Check demo mode
        const demo = await AsyncStorage.getItem('demoUser');
        if (!demo) { setUser(null); setProfile(null); setLoading(false); }
      }
    });
    return unsub;
  }, []);

  const loginDemo = async (role = 'student') => {
    const demoUser = {
      uid: 'demo_' + role,
      name: role === 'student' ? 'Demo Student' : 'Demo Teacher',
      email: role + '@demo.com',
      role,
      subject: 'UPSC CSE',
      examKey: 'UPSC CSE',
      target: 20,
      streak: 7,
      bestStreak: 12,
      isDemo: true,
    };
    await AsyncStorage.setItem('demoUser', JSON.stringify(demoUser));
    setUser(demoUser);
    setProfile(demoUser);
    setDemoMode(true);
  };

  const logout = async () => {
    await AsyncStorage.removeItem('demoUser');
    await AsyncStorage.removeItem('cachedProfile');
    setUser(null); setProfile(null); setDemoMode(false);
    if (!demoMode) { try { await fbSignOut(); } catch (e) {} }
  };

  const updateProfile = async (data) => {
    const updated = { ...profile, ...data };
    setProfile(updated);
    if (demoMode) {
      await AsyncStorage.setItem('demoUser', JSON.stringify(updated));
    } else {
      await AsyncStorage.setItem('cachedProfile', JSON.stringify(updated));
    }
  };

  return (
    <AuthContext.Provider value={{ user, profile, loading, demoMode, loginDemo, logout, updateProfile }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
