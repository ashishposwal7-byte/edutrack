export { ExamSelectorScreen as default } from '../AllOtherScreens';
