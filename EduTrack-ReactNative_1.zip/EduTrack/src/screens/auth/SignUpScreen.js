// src/screens/auth/SignUpScreen.js
import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, ScrollView, Alert, KeyboardAvoidingView, Platform } from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import { signUp } from '../../services/firebase';
import { Colors, Spacing, Radius, FontSize } from '../../utils/theme';

const ROLES = ['student', 'teacher'];

export default function SignUpScreen({ navigation }) {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState('student');
  const [loading, setLoading] = useState(false);

  const handleSignUp = async () => {
    if (!name || !email || !password) { Alert.alert('Error', 'Please fill in all fields'); return; }
    if (password.length < 6) { Alert.alert('Error', 'Password must be at least 6 characters'); return; }
    setLoading(true);
    try {
      await signUp(email.trim().toLowerCase(), password, name, role, '');
      // Navigate to exam selector for students
      if (role === 'student') navigation.navigate('ExamSelector');
    } catch (e) {
      Alert.alert('Sign Up Failed', e.message);
    }
    setLoading(false);
  };

  return (
    <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <LinearGradient colors={['#0f1a35', Colors.bg, Colors.bg]} style={{ flex: 1 }}>
        <ScrollView contentContainerStyle={styles.inner} showsVerticalScrollIndicator={false}>
          <View style={styles.header}>
            <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
              <Text style={{ color: Colors.accent, fontSize: 16 }}>← Back</Text>
            </TouchableOpacity>
            <Text style={styles.title}>Create Account</Text>
            <Text style={styles.sub}>Join thousands of students and teachers</Text>
          </View>

          <View style={styles.card}>
            <View style={styles.field}><Text style={styles.label}>FULL NAME</Text><TextInput style={styles.input} value={name} onChangeText={setName} placeholder="Your full name" placeholderTextColor={Colors.muted} /></View>
            <View style={styles.field}><Text style={styles.label}>EMAIL</Text><TextInput style={styles.input} value={email} onChangeText={setEmail} placeholder="you@example.com" placeholderTextColor={Colors.muted} keyboardType="email-address" autoCapitalize="none" /></View>
            <View style={styles.field}><Text style={styles.label}>PASSWORD</Text><TextInput style={styles.input} value={password} onChangeText={setPassword} placeholder="Min 6 characters" placeholderTextColor={Colors.muted} secureTextEntry /></View>

            <View style={styles.field}>
              <Text style={styles.label}>I AM A</Text>
              <View style={styles.roleRow}>
                {ROLES.map(r => (
                  <TouchableOpacity key={r} style={[styles.roleBtn, role === r && (r === 'student' ? styles.roleBtnActiveS : styles.roleBtnActiveT)]} onPress={() => setRole(r)}>
                    <Text style={{ fontSize: 24, marginBottom: 4 }}>{r === 'student' ? '🎓' : '👩‍🏫'}</Text>
                    <Text style={[styles.roleBtnText, role === r && { color: r === 'student' ? Colors.accent : Colors.accent2 }]}>{r === 'student' ? 'Student' : 'Teacher'}</Text>
                  </TouchableOpacity>
                ))}
              </View>
            </View>

            <TouchableOpacity onPress={handleSignUp} disabled={loading} style={{ marginTop: 8 }}>
              <LinearGradient colors={['#4F8EF7', '#7C5CFC']} style={styles.btn}>
                <Text style={styles.btnText}>{loading ? 'Creating...' : 'Create Account'}</Text>
              </LinearGradient>
            </TouchableOpacity>

            <TouchableOpacity onPress={() => navigation.navigate('Login')} style={{ marginTop: 16, alignItems: 'center' }}>
              <Text style={{ color: Colors.muted, fontSize: 13 }}>Already have an account? <Text style={{ color: Colors.accent }}>Sign in →</Text></Text>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </LinearGradient>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  inner: { padding: Spacing.xl, paddingTop: 60 },
  header: { marginBottom: Spacing.xl },
  backBtn: { marginBottom: 16 },
  title: { fontSize: 28, fontWeight: '700', color: Colors.text, letterSpacing: -0.5 },
  sub: { fontSize: 14, color: Colors.muted, marginTop: 4 },
  card: { backgroundColor: Colors.card, borderRadius: 20, padding: Spacing.xl, borderWidth: 1, borderColor: Colors.border },
  field: { marginBottom: Spacing.md },
  label: { fontSize: 11, color: Colors.muted, fontWeight: '600', letterSpacing: 1, marginBottom: 6 },
  input: { backgroundColor: Colors.surface, borderWidth: 1, borderColor: Colors.border, borderRadius: Radius.md, padding: Spacing.md, color: Colors.text, fontSize: 15 },
  roleRow: { flexDirection: 'row', gap: 12 },
  roleBtn: { flex: 1, padding: 14, borderWidth: 2, borderColor: Colors.border, borderRadius: Radius.md, alignItems: 'center' },
  roleBtnActiveS: { borderColor: Colors.accent, backgroundColor: '#4F8EF710' },
  roleBtnActiveT: { borderColor: Colors.accent2, backgroundColor: '#7C5CFC10' },
  roleBtnText: { color: Colors.muted, fontWeight: '600', fontSize: 14 },
  btn: { borderRadius: Radius.md, padding: Spacing.md, alignItems: 'center' },
  btnText: { color: '#fff', fontWeight: '700', fontSize: 16 },
});
