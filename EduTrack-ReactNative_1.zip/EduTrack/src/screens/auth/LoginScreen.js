// src/screens/auth/LoginScreen.js
import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, ScrollView, Alert, KeyboardAvoidingView, Platform } from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import { signIn } from '../../services/firebase';
import { useAuth } from '../../context/AuthContext';
import { Colors, Spacing, Radius, FontSize } from '../../utils/theme';

export default function LoginScreen({ navigation }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const { loginDemo } = useAuth();

  const handleLogin = async () => {
    if (!email || !password) { Alert.alert('Error', 'Please fill in all fields'); return; }
    setLoading(true);
    try {
      await signIn(email.trim().toLowerCase(), password);
    } catch (e) {
      Alert.alert('Login Failed', e.message || 'Invalid email or password');
    }
    setLoading(false);
  };

  return (
    <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <LinearGradient colors={['#0f1a35', Colors.bg, Colors.bg]} style={styles.container}>
        <ScrollView contentContainerStyle={styles.inner} showsVerticalScrollIndicator={false}>
          <View style={styles.brand}>
            <LinearGradient colors={['#4F8EF7', '#7C5CFC']} style={styles.brandIcon}>
              <Text style={{ fontSize: 32 }}>📚</Text>
            </LinearGradient>
            <Text style={styles.brandName}>EduTrack</Text>
            <Text style={styles.brandTagline}>Your AI-powered study companion</Text>
          </View>

          <View style={styles.card}>
            <Text style={styles.title}>Sign In</Text>

            <View style={styles.field}>
              <Text style={styles.label}>EMAIL</Text>
              <TextInput style={styles.input} value={email} onChangeText={setEmail} placeholder="you@example.com" placeholderTextColor={Colors.muted} keyboardType="email-address" autoCapitalize="none" />
            </View>
            <View style={styles.field}>
              <Text style={styles.label}>PASSWORD</Text>
              <TextInput style={styles.input} value={password} onChangeText={setPassword} placeholder="••••••••" placeholderTextColor={Colors.muted} secureTextEntry />
            </View>

            <TouchableOpacity onPress={handleLogin} disabled={loading} style={{ marginTop: 8 }}>
              <LinearGradient colors={['#4F8EF7', '#7C5CFC']} style={styles.btn}>
                <Text style={styles.btnText}>{loading ? 'Signing in...' : 'Sign In'}</Text>
              </LinearGradient>
            </TouchableOpacity>

            <View style={styles.divider}><View style={styles.line} /><Text style={styles.orText}>or</Text><View style={styles.line} /></View>

            <Text style={styles.demoLabel}>Try Demo Mode</Text>
            <View style={styles.demoRow}>
              <TouchableOpacity style={styles.demoBtn} onPress={() => loginDemo('student')}>
                <Text style={styles.demoBtnText}>🎓 Student Demo</Text>
              </TouchableOpacity>
              <TouchableOpacity style={[styles.demoBtn, { borderColor: Colors.accent2 }]} onPress={() => loginDemo('teacher')}>
                <Text style={[styles.demoBtnText, { color: Colors.accent2 }]}>👩‍🏫 Teacher Demo</Text>
              </TouchableOpacity>
            </View>

            <TouchableOpacity onPress={() => navigation.navigate('SignUp')} style={styles.switchRow}>
              <Text style={styles.switchText}>Don't have an account? <Text style={{ color: Colors.accent }}>Create one →</Text></Text>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </LinearGradient>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  inner: { padding: Spacing.xl, paddingTop: 60 },
  brand: { alignItems: 'center', marginBottom: Spacing.xxxl },
  brandIcon: { width: 72, height: 72, borderRadius: 20, justifyContent: 'center', alignItems: 'center', marginBottom: 12 },
  brandName: { fontSize: 32, fontWeight: '700', color: Colors.text, letterSpacing: -1 },
  brandTagline: { fontSize: 14, color: Colors.muted, marginTop: 4, fontStyle: 'italic' },
  card: { backgroundColor: Colors.card, borderRadius: 20, padding: Spacing.xl, borderWidth: 1, borderColor: Colors.border },
  title: { fontSize: FontSize.xl, fontWeight: '700', color: Colors.text, marginBottom: Spacing.lg },
  field: { marginBottom: Spacing.md },
  label: { fontSize: 11, color: Colors.muted, fontWeight: '600', letterSpacing: 1, marginBottom: 6 },
  input: { backgroundColor: Colors.surface, borderWidth: 1, borderColor: Colors.border, borderRadius: Radius.md, padding: Spacing.md, color: Colors.text, fontSize: 15 },
  btn: { borderRadius: Radius.md, padding: Spacing.md, alignItems: 'center' },
  btnText: { color: '#fff', fontWeight: '700', fontSize: 16 },
  divider: { flexDirection: 'row', alignItems: 'center', marginVertical: Spacing.lg },
  line: { flex: 1, height: 1, backgroundColor: Colors.border },
  orText: { color: Colors.muted, marginHorizontal: 12, fontSize: 12 },
  demoLabel: { fontSize: 12, color: Colors.muted, textAlign: 'center', marginBottom: 10 },
  demoRow: { flexDirection: 'row', gap: 10 },
  demoBtn: { flex: 1, padding: 10, borderWidth: 1, borderColor: Colors.accent, borderRadius: Radius.md, alignItems: 'center' },
  demoBtnText: { color: Colors.accent, fontWeight: '600', fontSize: 13 },
  switchRow: { marginTop: Spacing.lg, alignItems: 'center' },
  switchText: { color: Colors.muted, fontSize: 13 },
});
