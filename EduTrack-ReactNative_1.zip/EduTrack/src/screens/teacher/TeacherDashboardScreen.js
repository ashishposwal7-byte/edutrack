export { TeacherDashboardScreen as default } from '../AllOtherScreens';
