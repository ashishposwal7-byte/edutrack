export { StudentDetailScreen as default } from '../AllOtherScreens';
