export { ClassProgressScreen as default } from '../AllOtherScreens';
