// src/screens/student/KiloScreen.js
import React from 'react';
import { View, Text, ScrollView, StyleSheet, TouchableOpacity } from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import { useData } from '../../context/DataContext';
import { useAuth } from '../../context/AuthContext';
import { Colors, Spacing, Radius } from '../../utils/theme';

const MILESTONES = [
  { hours: 50,  icon: '🌱', label: 'First 50',      desc: "You've started the journey" },
  { hours: 100, icon: '💪', label: 'Century',        desc: '100 hours of focused work' },
  { hours: 200, icon: '⚡', label: '200 Strong',     desc: 'Building real momentum' },
  { hours: 300, icon: '🔥', label: 'On Fire',        desc: 'Consistent and committed' },
  { hours: 400, icon: '🎯', label: 'Four Hundred',   desc: 'Developing genuine skill' },
  { hours: 500, icon: '🏅', label: 'Halfway There',  desc: "You're halfway to mastery" },
  { hours: 600, icon: '🚀', label: 'Six Hundred',    desc: 'Well above average preparation' },
  { hours: 700, icon: '⚔️', label: 'Seven Hundred',  desc: 'Expert territory approaching' },
  { hours: 800, icon: '💎', label: 'Eight Hundred',  desc: 'Exceptional commitment' },
  { hours: 900, icon: '🌟', label: 'Nine Hundred',   desc: 'Elite preparation level' },
  { hours: 1000,icon: '🏆', label: '1000 Hours',     desc: "Mastery achieved — you're ready!" },
];

export default function KiloScreen({ navigation }) {
  const { totalStudyHours, sessions, weekHours } = useData();
  const { profile } = useAuth();

  const pct = Math.min(100, (totalStudyHours / 1000) * 100);
  const remaining = Math.max(0, 1000 - totalStudyHours);

  const today = new Date(); today.setHours(0, 0, 0, 0);
  const days = sessions.length ? Math.max(1, Math.round((today.getTime() - Math.min(...sessions.map(s => s.date || Date.now()))) / 86400000)) : 1;
  const avgDay = (totalStudyHours / days).toFixed(2);
  const etaDays = remaining > 0 && avgDay > 0 ? Math.ceil(remaining / parseFloat(avgDay)) : 0;

  const mStart = new Date(today.getFullYear(), today.getMonth(), 1).getTime();
  const monthMins = sessions.filter(s => (s.date || 0) >= mStart).reduce((a, s) => a + s.mins, 0);

  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>

      {/* Hero */}
      <LinearGradient colors={['#0a0f1e', '#120a2e']} style={styles.hero}>
        <Text style={styles.heroLabel}>⚡ MASTERY TRACKER</Text>
        <Text style={styles.heroTitle}>Your path to{'\n'}<Text style={styles.heroHighlight}>1,000 Hours</Text></Text>
        <Text style={styles.heroSub}>Research shows 1,000 focused hours is the threshold for genuine competence. Every session counts.</Text>

        <View style={styles.heroBig}>
          <Text style={styles.heroHours}>{totalStudyHours.toFixed(1)}</Text>
          <Text style={styles.heroSlash}>/ 1,000 hrs</Text>
        </View>

        <View style={styles.barTrack}>
          <LinearGradient colors={['#4F8EF7', '#7C5CFC']} style={[styles.barFill, { width: `${pct}%` }]} />
        </View>
        <View style={styles.barLabels}>
          <Text style={styles.barLbl}>{pct.toFixed(1)}% complete</Text>
          <Text style={styles.barLbl}>{remaining.toFixed(1)}h remaining</Text>
        </View>

        <View style={styles.pillsRow}>
          <View style={styles.pill}><Text style={styles.pillTxt}>📅 {avgDay}h/day pace</Text></View>
          <View style={styles.pill}><Text style={styles.pillTxt}>🎯 {etaDays > 0 ? etaDays + ' days left' : 'Done! 🎉'}</Text></View>
          <View style={styles.pill}><Text style={styles.pillTxt}>🔥 {profile?.streak || 0}-day streak</Text></View>
        </View>
      </LinearGradient>

      {/* Pace Stats */}
      <View style={styles.card}>
        <Text style={styles.cardTitle}>📊 Your Pace</Text>
        <View style={styles.paceGrid}>
          {[
            { val: totalStudyHours.toFixed(1) + 'h', lbl: 'Total Hours', color: Colors.accent },
            { val: weekHours + 'h', lbl: 'This Week', color: Colors.green },
            { val: (monthMins / 60).toFixed(1) + 'h', lbl: 'This Month', color: Colors.accent2 },
            { val: avgDay + 'h', lbl: 'Daily Avg', color: Colors.amber },
            { val: sessions.length, lbl: 'Sessions', color: Colors.pink },
            { val: etaDays > 0 ? etaDays + 'd' : '🎉', lbl: 'Days to Goal', color: Colors.red },
          ].map((s, i) => (
            <View key={i} style={styles.paceStat}>
              <Text style={[styles.paceVal, { color: s.color }]}>{s.val}</Text>
              <Text style={styles.paceLbl}>{s.lbl}</Text>
            </View>
          ))}
        </View>
      </View>

      {/* Milestones */}
      <View style={styles.card}>
        <Text style={styles.cardTitle}>🏅 Milestones</Text>
        {MILESTONES.map((m, i) => {
          const achieved = totalStudyHours >= m.hours;
          const isCurrent = !achieved && totalStudyHours >= m.hours - 100;
          const mpct = Math.min(100, (totalStudyHours / m.hours) * 100);
          return (
            <View key={i} style={[styles.msRow, achieved && styles.msAchieved, isCurrent && styles.msCurrent]}>
              <Text style={{ fontSize: 24 }}>{m.icon}</Text>
              <View style={{ flex: 1, marginHorizontal: 12 }}>
                <Text style={styles.msLabel}>{m.label} <Text style={styles.msHours}>({m.hours}h)</Text></Text>
                <Text style={styles.msDesc}>{m.desc}</Text>
                {!achieved && (
                  <View style={styles.msBar}><View style={[styles.msBarFill, { width: `${mpct}%`, backgroundColor: isCurrent ? Colors.accent : Colors.border }]} /></View>
                )}
              </View>
              {achieved ? <Text style={{ color: Colors.green, fontSize: 18 }}>✅</Text> : <Text style={styles.msLocked}>{m.hours}h</Text>}
            </View>
          );
        })}
      </View>

      <TouchableOpacity onPress={() => navigation.navigate('Study')} style={styles.ctaWrap}>
        <LinearGradient colors={['#4F8EF7', '#7C5CFC']} style={styles.cta}>
          <Text style={styles.ctaText}>⏱️ Log a Session Now</Text>
        </LinearGradient>
      </TouchableOpacity>

      <View style={{ height: 80 }} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.bg },
  hero: { margin: Spacing.lg, borderRadius: 18, padding: Spacing.xl, borderWidth: 1, borderColor: '#2a3550' },
  heroLabel: { fontSize: 11, color: Colors.accent2, fontWeight: '700', letterSpacing: 1.5, marginBottom: 8 },
  heroTitle: { fontSize: 28, fontWeight: '700', color: Colors.text, letterSpacing: -0.5, marginBottom: 8 },
  heroHighlight: { color: Colors.accent },
  heroSub: { fontSize: 13, color: Colors.muted, lineHeight: 20, marginBottom: 20 },
  heroBig: { flexDirection: 'row', alignItems: 'baseline', gap: 8, marginBottom: 12 },
  heroHours: { fontSize: 52, fontWeight: '700', color: Colors.accent, letterSpacing: -2 },
  heroSlash: { fontSize: 18, color: Colors.muted, fontWeight: '600' },
  barTrack: { height: 12, backgroundColor: '#1e2d4a', borderRadius: 99, overflow: 'hidden', marginBottom: 6 },
  barFill: { height: '100%', borderRadius: 99 },
  barLabels: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 16 },
  barLbl: { fontSize: 11, color: Colors.muted },
  pillsRow: { flexDirection: 'row', gap: 8, flexWrap: 'wrap' },
  pill: { paddingHorizontal: 10, paddingVertical: 5, borderRadius: 99, borderWidth: 1, borderColor: '#4F8EF730', backgroundColor: '#4F8EF710' },
  pillTxt: { fontSize: 11, color: Colors.accent, fontWeight: '600' },
  card: { marginHorizontal: Spacing.lg, marginBottom: Spacing.md, backgroundColor: Colors.card, borderRadius: Radius.lg, padding: Spacing.lg, borderWidth: 1, borderColor: Colors.border },
  cardTitle: { fontSize: 14, fontWeight: '700', color: Colors.text, marginBottom: 16 },
  paceGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10 },
  paceStat: { width: '30%', backgroundColor: Colors.surface, borderRadius: Radius.md, padding: 12, alignItems: 'center', borderWidth: 1, borderColor: Colors.border },
  paceVal: { fontSize: 20, fontWeight: '700' },
  paceLbl: { fontSize: 10, color: Colors.muted, textAlign: 'center', marginTop: 2 },
  msRow: { flexDirection: 'row', alignItems: 'center', padding: 12, borderRadius: Radius.md, marginBottom: 8, borderWidth: 1, borderColor: Colors.border, opacity: 0.6 },
  msAchieved: { borderColor: Colors.green, backgroundColor: '#34D39908', opacity: 1 },
  msCurrent: { borderColor: Colors.accent, backgroundColor: '#4F8EF708', opacity: 1 },
  msLabel: { fontSize: 14, fontWeight: '700', color: Colors.text },
  msHours: { fontSize: 12, color: Colors.muted, fontWeight: '400' },
  msDesc: { fontSize: 12, color: Colors.muted, marginTop: 2 },
  msBar: { height: 4, backgroundColor: Colors.border, borderRadius: 99, overflow: 'hidden', marginTop: 6 },
  msBarFill: { height: '100%', borderRadius: 99 },
  msLocked: { fontSize: 11, color: Colors.muted, fontWeight: '600' },
  ctaWrap: { marginHorizontal: Spacing.lg, marginBottom: Spacing.lg },
  cta: { borderRadius: Radius.md, padding: 16, alignItems: 'center' },
  ctaText: { color: '#fff', fontSize: 16, fontWeight: '700' },
});
