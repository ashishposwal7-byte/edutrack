export { ResourcesScreen as default } from '../AllStudentScreens';
