// src/screens/student/ExamSyllabusScreen.js
import React, { useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet, Alert } from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import { useAuth } from '../../context/AuthContext';
import { useData } from '../../context/DataContext';
import { EXAM_DB } from '../../data/exams';
import { Colors, Spacing, Radius } from '../../utils/theme';

export default function ExamSyllabusScreen({ navigation }) {
  const { profile } = useAuth();
  const { topics, updateTopicStatus, topicsDone, topicsTotal, topicsPct } = useData();
  const [subjectFilter, setSubjectFilter] = useState('All');

  const examKey = profile?.examKey || profile?.subject;
  const exam = EXAM_DB[examKey];
  const subjects = exam ? Object.keys(exam.subjects) : [];
  const examTopics = topics.filter(t => t.examKey === examKey || subjects.includes(t.subject));
  const filtered = subjectFilter === 'All' ? examTopics : examTopics.filter(t => t.subject === subjectFilter);

  const grouped = {};
  filtered.forEach(t => { if (!grouped[t.subject]) grouped[t.subject] = []; grouped[t.subject].push(t); });

  const cycle = async (topic) => {
    const next = { pending: 'inprogress', inprogress: 'done', done: 'pending' }[topic.status];
    await updateTopicStatus(topic.id, next);
  };

  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
      <LinearGradient colors={['#0f1a35', Colors.bg]} style={styles.header}>
        <Text style={styles.headerTitle}>🎯 Exam Syllabus</Text>
        <Text style={styles.headerSub}>{exam?.fullName || examKey || 'No exam selected'}</Text>
        <TouchableOpacity onPress={() => navigation.navigate('ExamSelector')} style={styles.changeBtn}>
          <Text style={styles.changeBtnText}>Change Exam →</Text>
        </TouchableOpacity>
      </LinearGradient>

      {/* Overall */}
      <View style={styles.overallCard}>
        <View style={styles.overallRow}>
          <Text style={styles.overallLabel}>Overall Completion</Text>
          <Text style={[styles.overallPct, { color: Colors.accent }]}>{topicsPct}%</Text>
        </View>
        <View style={styles.barTrack}><View style={[styles.barFill, { width: `${topicsPct}%` }]} /></View>
        <View style={styles.overallStats}>
          <Text style={styles.overallStat}><Text style={{ color: Colors.green }}>✅ {topicsDone}</Text> done</Text>
          <Text style={styles.overallStat}><Text style={{ color: Colors.amber }}>📖 {examTopics.filter(t => t.status === 'inprogress').length}</Text> in progress</Text>
          <Text style={styles.overallStat}><Text style={{ color: Colors.muted }}>⏳ {examTopics.filter(t => t.status === 'pending').length}</Text> pending</Text>
        </View>
      </View>

      {/* Subject filter tabs */}
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.tabs}>
        {['All', ...subjects].map(s => (
          <TouchableOpacity key={s} style={[styles.tab, subjectFilter === s && styles.tabActive]} onPress={() => setSubjectFilter(s)}>
            <Text style={[styles.tabText, subjectFilter === s && { color: Colors.accent }]} numberOfLines={1}>{s.split(' ').slice(0, 2).join(' ')}</Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      {/* Topic Groups */}
      {Object.entries(grouped).map(([subj, ts]) => {
        const done = ts.filter(t => t.status === 'done').length;
        const pct = Math.round(done / ts.length * 100);
        const colors = { done: Colors.green, inprogress: Colors.amber, pending: Colors.muted };
        return (
          <View key={subj} style={styles.subjectCard}>
            <View style={styles.subjHdr}>
              <Text style={styles.subjName}>{subj}</Text>
              <Text style={styles.subjPct}>{done}/{ts.length} · {pct}%</Text>
            </View>
            <View style={styles.barTrack}><View style={[styles.barFill, { width: `${pct}%` }]} /></View>
            {ts.map(t => (
              <TouchableOpacity key={t.id} style={styles.topicRow} onPress={() => cycle(t)}>
                <View style={[styles.topicCheck, t.status === 'done' && styles.topicCheckDone, t.status === 'inprogress' && styles.topicCheckInProg]}>
                  <Text style={{ fontSize: 10, color: t.status === 'pending' ? 'transparent' : '#fff' }}>{t.status === 'done' ? '✓' : '~'}</Text>
                </View>
                <Text style={[styles.topicName, t.status === 'done' && styles.topicNameDone]} numberOfLines={2}>{t.name}</Text>
                <View style={[styles.statusDot, { backgroundColor: colors[t.status] }]} />
              </TouchableOpacity>
            ))}
          </View>
        );
      })}

      {!examKey && (
        <View style={styles.noExam}>
          <Text style={{ fontSize: 40, marginBottom: 12 }}>🎯</Text>
          <Text style={styles.noExamTitle}>No Exam Selected</Text>
          <Text style={styles.noExamSub}>Choose your target exam to load its official syllabus</Text>
          <TouchableOpacity onPress={() => navigation.navigate('ExamSelector')}>
            <LinearGradient colors={['#4F8EF7', '#7C5CFC']} style={styles.noExamBtn}>
              <Text style={styles.noExamBtnText}>Select Exam →</Text>
            </LinearGradient>
          </TouchableOpacity>
        </View>
      )}

      <View style={{ height: 80 }} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.bg },
  header: { padding: Spacing.xl, paddingTop: Spacing.xxl },
  headerTitle: { fontSize: 24, fontWeight: '700', color: Colors.text },
  headerSub: { fontSize: 13, color: Colors.muted, marginTop: 4, marginBottom: 12 },
  changeBtn: { alignSelf: 'flex-start', paddingHorizontal: 12, paddingVertical: 6, borderRadius: Radius.sm, borderWidth: 1, borderColor: Colors.accent },
  changeBtnText: { color: Colors.accent, fontSize: 13, fontWeight: '600' },
  overallCard: { margin: Spacing.lg, backgroundColor: Colors.card, borderRadius: Radius.lg, padding: Spacing.lg, borderWidth: 1, borderColor: Colors.border },
  overallRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 8 },
  overallLabel: { fontSize: 14, fontWeight: '700', color: Colors.text },
  overallPct: { fontSize: 16, fontWeight: '700' },
  barTrack: { height: 8, backgroundColor: Colors.border, borderRadius: 99, overflow: 'hidden', marginBottom: 10 },
  barFill: { height: '100%', backgroundColor: Colors.accent, borderRadius: 99 },
  overallStats: { flexDirection: 'row', gap: 16 },
  overallStat: { fontSize: 12, color: Colors.muted },
  tabs: { paddingHorizontal: Spacing.lg, paddingBottom: Spacing.sm, gap: 8 },
  tab: { paddingHorizontal: 12, paddingVertical: 6, borderRadius: 99, borderWidth: 1, borderColor: Colors.border, backgroundColor: Colors.surface },
  tabActive: { borderColor: Colors.accent, backgroundColor: '#4F8EF718' },
  tabText: { fontSize: 12, fontWeight: '600', color: Colors.muted },
  subjectCard: { marginHorizontal: Spacing.lg, marginBottom: Spacing.md, backgroundColor: Colors.card, borderRadius: Radius.lg, padding: Spacing.lg, borderWidth: 1, borderColor: Colors.border },
  subjHdr: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 8 },
  subjName: { fontSize: 14, fontWeight: '700', color: Colors.text, flex: 1 },
  subjPct: { fontSize: 12, color: Colors.muted },
  topicRow: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 8, borderBottomWidth: 1, borderBottomColor: Colors.border + '60' },
  topicCheck: { width: 22, height: 22, borderRadius: 6, borderWidth: 2, borderColor: Colors.border, justifyContent: 'center', alignItems: 'center' },
  topicCheckDone: { backgroundColor: Colors.green, borderColor: Colors.green },
  topicCheckInProg: { backgroundColor: Colors.amber, borderColor: Colors.amber },
  topicName: { flex: 1, fontSize: 13, color: Colors.text, lineHeight: 18 },
  topicNameDone: { textDecorationLine: 'line-through', color: Colors.muted },
  statusDot: { width: 7, height: 7, borderRadius: 99 },
  noExam: { margin: Spacing.xl, alignItems: 'center', padding: Spacing.xl },
  noExamTitle: { fontSize: 20, fontWeight: '700', color: Colors.text, marginBottom: 8 },
  noExamSub: { fontSize: 14, color: Colors.muted, textAlign: 'center', marginBottom: 20 },
  noExamBtn: { paddingHorizontal: 24, paddingVertical: 12, borderRadius: Radius.md },
  noExamBtnText: { color: '#fff', fontWeight: '700', fontSize: 15 },
});
