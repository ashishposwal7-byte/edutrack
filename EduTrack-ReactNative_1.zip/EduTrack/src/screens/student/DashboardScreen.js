// src/screens/student/DashboardScreen.js
import React, { useRef, useEffect } from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet, Animated, Dimensions } from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import { useAuth } from '../../context/AuthContext';
import { useData } from '../../context/DataContext';
import { Colors, Spacing, Radius, FontSize } from '../../utils/theme';

const { width } = Dimensions.get('window');

const QUOTES = [
  '"Success is the sum of small efforts, repeated day in and day out." — Robert Collier',
  '"The secret of getting ahead is getting started." — Mark Twain',
  '"An investment in knowledge pays the best interest." — Benjamin Franklin',
  '"Dream big. Start small. Act now." — Robin Sharma',
  '"You don\'t have to be great to start, but you have to start to be great." — Zig Ziglar',
];

const MetricCard = ({ icon, value, label, sub, color, barPct }) => (
  <View style={[styles.metricCard, { borderBottomColor: color }]}>
    <Text style={{ fontSize: 22, marginBottom: 6 }}>{icon}</Text>
    <Text style={[styles.metricVal, { color }]}>{value}</Text>
    <Text style={styles.metricLabel}>{label}</Text>
    {sub && <Text style={styles.metricSub}>{sub}</Text>}
    {barPct !== undefined && (
      <View style={styles.metricBar}><View style={[styles.metricBarFill, { width: `${barPct}%`, backgroundColor: color }]} /></View>
    )}
  </View>
);

const TaskItem = ({ task, onToggle }) => {
  const prColor = { high: Colors.red, medium: Colors.amber, low: Colors.green }[task.priority] || Colors.border;
  return (
    <TouchableOpacity style={styles.taskRow} onPress={() => onToggle(task.id)}>
      <View style={[styles.taskCheck, task.done && styles.taskCheckDone]}>
        {task.done && <Text style={{ color: '#fff', fontSize: 11 }}>✓</Text>}
      </View>
      <Text style={[styles.taskTitle, task.done && styles.taskTitleDone]} numberOfLines={1}>{task.title}</Text>
      <View style={[styles.taskPriDot, { backgroundColor: prColor }]} />
    </TouchableOpacity>
  );
};

const WeekBar = ({ data }) => {
  const max = Math.max(...data.map(d => d.mins), 60);
  const days = ['S', 'M', 'T', 'W', 'T', 'F', 'S'];
  return (
    <View style={styles.weekBarWrap}>
      {data.map((d, i) => (
        <View key={i} style={styles.weekBarCol}>
          <View style={styles.weekBarTrack}>
            <LinearGradient
              colors={d.isToday ? ['#4F8EF7', '#7C5CFC'] : ['#4F8EF7', '#4F8EF7']}
              style={[styles.weekBarFill, { height: `${Math.max(3, (d.mins / max) * 100)}%`, opacity: d.mins ? 1 : 0.2 }]}
            />
          </View>
          <Text style={[styles.weekBarLbl, d.isToday && { color: Colors.accent, fontWeight: '700' }]}>{days[i]}</Text>
        </View>
      ))}
    </View>
  );
};

export default function DashboardScreen({ navigation }) {
  const { profile } = useAuth();
  const { sessions, topics, scores, tasks, pendingTasks, pendingAssignments, weekHours, topicsDone, topicsTotal, topicsPct, avgScore, totalStudyHours, kilo_pct, todayStr, toggleTask } = useData();
  const ringAnim = useRef(new Animated.Value(0)).current;

  const hour = new Date().getHours();
  const greeting = hour < 12 ? 'morning' : hour < 17 ? 'afternoon' : 'evening';
  const quote = QUOTES[new Date().getDate() % QUOTES.length];
  const firstName = (profile?.name || 'Student').split(' ')[0];

  // Week chart data
  const today = new Date(); today.setHours(0, 0, 0, 0);
  const weekData = Array.from({ length: 7 }, (_, i) => {
    const d = today.getTime() - (6 - i) * 86400000;
    const mins = sessions.filter(s => (s.date || 0) >= d && (s.date || 0) < d + 86400000).reduce((a, s) => a + s.mins, 0);
    return { mins, isToday: i === 6 };
  });

  // Animate ring on mount
  useEffect(() => {
    Animated.timing(ringAnim, { toValue: topicsPct, duration: 1200, useNativeDriver: false }).start();
  }, [topicsPct]);

  const todayTasks = tasks.filter(t => t.date === todayStr).slice(0, 5);
  const recentScores = [...scores].sort((a, b) => (b.date || 0) - (a.date || 0)).slice(0, 3);
  const weekMins = weekData.reduce((a, d) => a + d.mins, 0);

  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>

      {/* Quote */}
      <LinearGradient colors={['#4F8EF710', '#7C5CFC10']} style={styles.quoteStrip}>
        <Text style={{ fontSize: 16 }}>💡</Text>
        <Text style={styles.quoteText} numberOfLines={2}>{quote}</Text>
      </LinearGradient>

      {/* Hero Banner */}
      <LinearGradient colors={['#0f1a35', '#120a2e']} style={styles.hero}>
        <View style={styles.heroTop}>
          <View style={{ flex: 1 }}>
            <Text style={styles.heroGreeting}>Good {greeting},</Text>
            <Text style={styles.heroName}>{firstName} 👋</Text>
            <Text style={styles.heroDate}>{new Date().toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'long' })}</Text>
          </View>
          {/* Progress Ring */}
          <View style={styles.ringWrap}>
            <View style={styles.ringOuter}>
              <View style={styles.ringInner}>
                <Text style={styles.ringPct}>{topicsPct}%</Text>
                <Text style={styles.ringLbl}>done</Text>
              </View>
            </View>
          </View>
        </View>
        {/* Pills */}
        <View style={styles.pillsRow}>
          <View style={[styles.pill, { borderColor: '#34D39930' }]}>
            <Text style={[styles.pillText, { color: Colors.green }]}>🔥 {profile?.streak || 0} day streak</Text>
          </View>
          <View style={[styles.pill, { borderColor: '#4F8EF730' }]}>
            <Text style={[styles.pillText, { color: Colors.accent }]}>⏱️ {weekHours}h this week</Text>
          </View>
          <View style={[styles.pill, { borderColor: '#FBBF2430' }]}>
            <Text style={[styles.pillText, { color: Colors.amber }]}>🏆 avg {avgScore !== null ? avgScore + '%' : '—'}</Text>
          </View>
        </View>
      </LinearGradient>

      {/* Metric Strip */}
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.metricStrip} contentContainerStyle={{ paddingHorizontal: Spacing.lg, gap: Spacing.sm }}>
        <MetricCard icon="📚" value={topicsDone} label="Topics Done" sub={`of ${topicsTotal}`} color={Colors.accent} barPct={topicsPct} />
        <MetricCard icon="⚡" value={totalStudyHours.toFixed(1)} label="Total Hours" sub="of 1,000 goal" color={Colors.accent2} barPct={kilo_pct} />
        <MetricCard icon="⏱️" value={weekHours} label="Week Hours" sub={`of ${profile?.target || 20}h target`} color={Colors.green} barPct={Math.min(100, weekHours / (profile?.target || 20) * 100)} />
        <MetricCard icon="✅" value={pendingTasks} label="Tasks Today" sub="pending" color={Colors.pink} />
        <MetricCard icon="📌" value={pendingAssignments} label="Assignments" sub="pending" color={Colors.red} />
        <MetricCard icon="🏆" value={avgScore !== null ? avgScore + '%' : '—'} label="Avg Score" sub="all tests" color={Colors.amber} />
      </ScrollView>

      {/* Week Chart */}
      <View style={styles.card}>
        <View style={styles.cardHdr}>
          <Text style={styles.cardTitle}>📊 Study Hours — This Week</Text>
          <Text style={styles.cardMeta}>{(weekMins / 60).toFixed(1)}h total</Text>
        </View>
        <WeekBar data={weekData} />
        <View style={styles.weekStats}>
          <View style={styles.weekStat}><Text style={[styles.weekStatVal, { color: Colors.accent }]}>{weekData.filter(d => d.mins > 0).length}</Text><Text style={styles.weekStatLbl}>Active days</Text></View>
          <View style={styles.weekStat}><Text style={[styles.weekStatVal, { color: Colors.green }]}>{Math.max(...weekData.map(d => d.mins / 60), 0).toFixed(1)}h</Text><Text style={styles.weekStatLbl}>Best day</Text></View>
          <View style={styles.weekStat}><Text style={[styles.weekStatVal, { color: Colors.accent2 }]}>{(weekMins / 7 / 60).toFixed(1)}h</Text><Text style={styles.weekStatLbl}>Daily avg</Text></View>
        </View>
      </View>

      {/* Today's Tasks */}
      <View style={styles.card}>
        <View style={styles.cardHdr}>
          <Text style={styles.cardTitle}>✅ Today's Tasks</Text>
          <TouchableOpacity onPress={() => navigation.navigate('More', { screen: 'Tasks' })}>
            <Text style={styles.cardLink}>View all →</Text>
          </TouchableOpacity>
        </View>
        {todayTasks.length === 0 ? (
          <TouchableOpacity onPress={() => navigation.navigate('More', { screen: 'Tasks' })} style={styles.emptyState}>
            <Text style={styles.emptyText}>No tasks yet — add one!</Text>
          </TouchableOpacity>
        ) : todayTasks.map(t => <TaskItem key={t.id} task={t} onToggle={toggleTask} />)}
      </View>

      {/* Quick Actions */}
      <View style={styles.card}>
        <Text style={styles.cardTitle}>🚀 Quick Actions</Text>
        <View style={styles.quickGrid}>
          {[
            { icon: '🤖', label: 'AI Planner', screen: 'Planner', color: '#4F8EF7' },
            { icon: '⏱️', label: 'Start Timer', screen: 'Study', color: '#34D399' },
            { icon: '🎯', label: 'Exam Syllabus', screen: 'More', params: { screen: 'Exam Syllabus' }, color: '#7C5CFC' },
            { icon: '⚡', label: '1000-Hour', screen: 'More', params: { screen: '1000-Hour Tracker' }, color: '#FBBF24' },
          ].map((a, i) => (
            <TouchableOpacity key={i} style={[styles.quickBtn, { borderColor: a.color + '40' }]} onPress={() => navigation.navigate(a.screen, a.params)}>
              <Text style={{ fontSize: 22 }}>{a.icon}</Text>
              <Text style={[styles.quickBtnLabel, { color: a.color }]}>{a.label}</Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>

      {/* Recent Scores */}
      {recentScores.length > 0 && (
        <View style={styles.card}>
          <View style={styles.cardHdr}>
            <Text style={styles.cardTitle}>🏆 Recent Scores</Text>
            <TouchableOpacity onPress={() => navigation.navigate('More', { screen: 'Test Scores' })}>
              <Text style={styles.cardLink}>View all →</Text>
            </TouchableOpacity>
          </View>
          {recentScores.map(s => {
            const color = s.score >= 80 ? Colors.green : s.score >= 60 ? Colors.amber : Colors.red;
            return (
              <View key={s.id} style={styles.scoreRow}>
                <View style={[styles.scoreCircle, { backgroundColor: color + '20' }]}>
                  <Text style={[styles.scoreCircleText, { color }]}>{s.score}</Text>
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={styles.scoreName}>{s.name}</Text>
                  <Text style={styles.scoreMeta}>{s.subject}{s.rank ? ` · Rank #${s.rank}` : ''}</Text>
                </View>
                <Text style={[styles.scorePct, { color }]}>{s.score}%</Text>
              </View>
            );
          })}
        </View>
      )}

      <View style={{ height: 80 }} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.bg },
  quoteStrip: { margin: Spacing.lg, marginBottom: 0, borderRadius: Radius.md, padding: 12, flexDirection: 'row', alignItems: 'center', gap: 10, borderWidth: 1, borderColor: '#4F8EF722' },
  quoteText: { flex: 1, fontSize: 12, color: Colors.muted, fontStyle: 'italic', lineHeight: 18 },
  hero: { margin: Spacing.lg, borderRadius: 18, padding: Spacing.lg, borderWidth: 1, borderColor: '#2a3550' },
  heroTop: { flexDirection: 'row', alignItems: 'center', marginBottom: 16 },
  heroGreeting: { fontSize: 14, color: Colors.muted },
  heroName: { fontSize: 26, fontWeight: '700', color: Colors.text, letterSpacing: -0.5 },
  heroDate: { fontSize: 12, color: Colors.muted, marginTop: 2 },
  ringWrap: { marginLeft: 16 },
  ringOuter: { width: 80, height: 80, borderRadius: 40, borderWidth: 6, borderColor: Colors.accent, justifyContent: 'center', alignItems: 'center', backgroundColor: Colors.card },
  ringInner: { alignItems: 'center' },
  ringPct: { fontSize: 20, fontWeight: '700', color: Colors.accent },
  ringLbl: { fontSize: 10, color: Colors.muted },
  pillsRow: { flexDirection: 'row', gap: 8, flexWrap: 'wrap' },
  pill: { paddingHorizontal: 10, paddingVertical: 5, borderRadius: 99, borderWidth: 1, backgroundColor: '#ffffff08' },
  pillText: { fontSize: 11, fontWeight: '600' },
  metricStrip: { paddingVertical: Spacing.sm },
  metricCard: { width: 130, backgroundColor: Colors.card, borderRadius: Radius.md, padding: 14, borderWidth: 1, borderColor: Colors.border, borderBottomWidth: 3 },
  metricVal: { fontSize: 26, fontWeight: '700', lineHeight: 30 },
  metricLabel: { fontSize: 10, color: Colors.muted, textTransform: 'uppercase', letterSpacing: 0.5, fontWeight: '600', marginTop: 2 },
  metricSub: { fontSize: 10, color: Colors.muted, marginTop: 2 },
  metricBar: { height: 4, backgroundColor: Colors.border, borderRadius: 99, overflow: 'hidden', marginTop: 8 },
  metricBarFill: { height: '100%', borderRadius: 99 },
  card: { margin: Spacing.lg, marginTop: 0, backgroundColor: Colors.card, borderRadius: Radius.lg, padding: Spacing.lg, borderWidth: 1, borderColor: Colors.border },
  cardHdr: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14 },
  cardTitle: { fontSize: 14, fontWeight: '700', color: Colors.text },
  cardMeta: { fontSize: 12, color: Colors.muted },
  cardLink: { fontSize: 12, color: Colors.accent, fontWeight: '600' },
  weekBarWrap: { flexDirection: 'row', gap: 6, height: 80, alignItems: 'flex-end' },
  weekBarCol: { flex: 1, alignItems: 'center', gap: 4 },
  weekBarTrack: { flex: 1, width: '100%', justifyContent: 'flex-end' },
  weekBarFill: { borderRadius: 4, width: '100%', minHeight: 3 },
  weekBarLbl: { fontSize: 10, color: Colors.muted },
  weekStats: { flexDirection: 'row', marginTop: 16, paddingTop: 12, borderTopWidth: 1, borderTopColor: Colors.border },
  weekStat: { flex: 1, alignItems: 'center' },
  weekStatVal: { fontSize: 18, fontWeight: '700' },
  weekStatLbl: { fontSize: 10, color: Colors.muted, marginTop: 2 },
  taskRow: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 8, borderBottomWidth: 1, borderBottomColor: Colors.border + '80' },
  taskCheck: { width: 20, height: 20, borderRadius: 10, borderWidth: 2, borderColor: Colors.border, justifyContent: 'center', alignItems: 'center' },
  taskCheckDone: { backgroundColor: Colors.green, borderColor: Colors.green },
  taskTitle: { flex: 1, fontSize: 14, color: Colors.text },
  taskTitleDone: { textDecorationLine: 'line-through', color: Colors.muted },
  taskPriDot: { width: 7, height: 7, borderRadius: 99 },
  emptyState: { padding: 12, alignItems: 'center' },
  emptyText: { fontSize: 13, color: Colors.muted },
  quickGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginTop: 12 },
  quickBtn: { width: (width - Spacing.lg * 2 - Spacing.lg * 2 - 10) / 2, padding: 14, borderRadius: Radius.md, borderWidth: 1, alignItems: 'center', gap: 6, backgroundColor: Colors.surface },
  quickBtnLabel: { fontSize: 12, fontWeight: '700' },
  scoreRow: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 8, borderBottomWidth: 1, borderBottomColor: Colors.border + '60' },
  scoreCircle: { width: 44, height: 44, borderRadius: 22, justifyContent: 'center', alignItems: 'center' },
  scoreCircleText: { fontSize: 13, fontWeight: '700' },
  scoreName: { fontSize: 13, fontWeight: '600', color: Colors.text },
  scoreMeta: { fontSize: 11, color: Colors.muted, marginTop: 2 },
  scorePct: { fontSize: 16, fontWeight: '700' },
});
