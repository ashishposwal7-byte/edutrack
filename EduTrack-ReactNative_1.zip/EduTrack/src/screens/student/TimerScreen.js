// src/screens/student/TimerScreen.js
import React, { useState, useEffect, useRef } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ScrollView, TextInput, Alert } from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import { useData } from '../../context/DataContext';
import { Colors, Spacing, Radius } from '../../utils/theme';

const PRESETS = [{ mins: 25, label: '25 min', sub: 'Pomodoro' }, { mins: 45, label: '45 min', sub: 'Deep work' }, { mins: 60, label: '60 min', sub: 'Power hour' }, { mins: 90, label: '90 min', sub: 'Long session' }];

export default function TimerScreen() {
  const { addSession, sessions } = useData();
  const [totalSecs, setTotalSecs] = useState(25 * 60);
  const [secsLeft, setSecsLeft] = useState(25 * 60);
  const [running, setRunning] = useState(false);
  const [label, setLabel] = useState('Study session');
  const intervalRef = useRef(null);

  const today = new Date(); today.setHours(0, 0, 0, 0);
  const todaySess = sessions.filter(s => (s.date || 0) >= today.getTime());
  const todayMins = todaySess.reduce((a, s) => a + s.mins, 0);

  useEffect(() => {
    if (running) {
      intervalRef.current = setInterval(() => {
        setSecsLeft(s => {
          if (s <= 1) { clearInterval(intervalRef.current); setRunning(false); handleSessionDone(Math.round(totalSecs / 60)); return 0; }
          return s - 1;
        });
      }, 1000);
    } else {
      clearInterval(intervalRef.current);
    }
    return () => clearInterval(intervalRef.current);
  }, [running]);

  const handleSessionDone = async (mins) => {
    if (mins < 1) return;
    await addSession(mins, label);
    Alert.alert('🎉 Session Complete!', `You studied for ${mins} minutes. Keep it up!`);
    setSecsLeft(totalSecs);
  };

  const toggleTimer = () => setRunning(r => !r);

  const resetTimer = () => {
    setRunning(false);
    setSecsLeft(totalSecs);
  };

  const logManual = async () => {
    const elapsed = Math.round((totalSecs - secsLeft) / 60);
    if (elapsed < 1) { Alert.alert('No time logged', 'Start the timer first or run it for at least 1 minute.'); return; }
    setRunning(false);
    await addSession(elapsed, label);
    setSecsLeft(totalSecs);
  };

  const setPreset = (mins) => {
    if (running) return;
    setTotalSecs(mins * 60);
    setSecsLeft(mins * 60);
  };

  const m = Math.floor(secsLeft / 60), s = secsLeft % 60;
  const pct = secsLeft / totalSecs;
  const circumference = 2 * Math.PI * 70;
  const strokeOffset = circumference * pct;

  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
      <Text style={styles.pageTitle}>Study Timer ⏱️</Text>

      {/* Ring Timer */}
      <LinearGradient colors={['#0f1a35', '#0a0f1e']} style={styles.timerCard}>
        <View style={styles.ringWrap}>
          <View style={styles.ringCenter}>
            <Text style={styles.timerNum}>{String(m).padStart(2, '0')}:{String(s).padStart(2, '0')}</Text>
            <Text style={styles.timerLabel}>{running ? 'Focusing... 💪' : secsLeft === totalSecs ? 'Ready to focus?' : 'Paused'}</Text>
          </View>
        </View>

        {/* Session Label */}
        <TextInput style={styles.labelInput} value={label} onChangeText={setLabel} placeholder="What are you studying?" placeholderTextColor={Colors.muted} />

        {/* Controls */}
        <View style={styles.controls}>
          <TouchableOpacity style={[styles.ctrlBtn, { backgroundColor: running ? Colors.amber : Colors.green }]} onPress={toggleTimer}>
            <Text style={styles.ctrlBtnText}>{running ? '⏸ Pause' : '▶ Start'}</Text>
          </TouchableOpacity>
          <TouchableOpacity style={[styles.ctrlBtn, { backgroundColor: Colors.border }]} onPress={resetTimer}>
            <Text style={[styles.ctrlBtnText, { color: Colors.text }]}>↺ Reset</Text>
          </TouchableOpacity>
          {!running && secsLeft < totalSecs && (
            <TouchableOpacity style={[styles.ctrlBtn, { backgroundColor: Colors.red }]} onPress={logManual}>
              <Text style={styles.ctrlBtnText}>■ Log</Text>
            </TouchableOpacity>
          )}
        </View>

        {/* Presets */}
        <View style={styles.presets}>
          {PRESETS.map(p => (
            <TouchableOpacity key={p.mins} style={[styles.preset, totalSecs === p.mins * 60 && styles.presetActive]} onPress={() => setPreset(p.mins)} disabled={running}>
              <Text style={[styles.presetMins, totalSecs === p.mins * 60 && { color: Colors.accent }]}>{p.label}</Text>
              <Text style={styles.presetSub}>{p.sub}</Text>
            </TouchableOpacity>
          ))}
        </View>
      </LinearGradient>

      {/* Today Stats */}
      <View style={styles.statsRow}>
        <View style={styles.statBox}>
          <Text style={[styles.statVal, { color: Colors.green }]}>{todayMins}</Text>
          <Text style={styles.statLbl}>Minutes today</Text>
        </View>
        <View style={styles.statBox}>
          <Text style={[styles.statVal, { color: Colors.accent }]}>{(todayMins / 60).toFixed(1)}h</Text>
          <Text style={styles.statLbl}>Hours today</Text>
        </View>
        <View style={styles.statBox}>
          <Text style={[styles.statVal, { color: Colors.accent2 }]}>{todaySess.length}</Text>
          <Text style={styles.statLbl}>Sessions</Text>
        </View>
      </View>

      {/* Session Log */}
      <View style={styles.logCard}>
        <Text style={styles.logTitle}>Today's Sessions</Text>
        {todaySess.length === 0 ? (
          <Text style={styles.emptyText}>Start your first session!</Text>
        ) : todaySess.map((s, i) => (
          <View key={s.id || i} style={styles.logRow}>
            <Text style={styles.logLabel}>{s.label}</Text>
            <Text style={styles.logDur}>{s.mins} min</Text>
          </View>
        ))}
        {todaySess.length > 0 && (
          <View style={styles.logTotal}>
            <Text style={styles.logTotalLabel}>Total today</Text>
            <Text style={[styles.logTotalVal, { color: Colors.green }]}>{todayMins} min</Text>
          </View>
        )}
      </View>

      <View style={{ height: 80 }} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.bg },
  pageTitle: { fontSize: 22, fontWeight: '700', color: Colors.text, margin: Spacing.lg, marginBottom: 0 },
  timerCard: { margin: Spacing.lg, borderRadius: 18, padding: Spacing.xl, borderWidth: 1, borderColor: '#2a3550', alignItems: 'center' },
  ringWrap: { width: 180, height: 180, justifyContent: 'center', alignItems: 'center', borderRadius: 90, borderWidth: 10, borderColor: Colors.accent, marginBottom: 20, backgroundColor: Colors.card },
  ringCenter: { alignItems: 'center' },
  timerNum: { fontSize: 38, fontWeight: '700', color: Colors.text, letterSpacing: -2 },
  timerLabel: { fontSize: 13, color: Colors.muted, marginTop: 4 },
  labelInput: { width: '100%', backgroundColor: Colors.surface, borderWidth: 1, borderColor: Colors.border, borderRadius: Radius.md, padding: 10, color: Colors.text, fontSize: 14, textAlign: 'center', marginBottom: 16 },
  controls: { flexDirection: 'row', gap: 10, marginBottom: 16 },
  ctrlBtn: { paddingHorizontal: 20, paddingVertical: 12, borderRadius: Radius.md },
  ctrlBtnText: { color: '#000', fontWeight: '700', fontSize: 14 },
  presets: { flexDirection: 'row', gap: 8, width: '100%' },
  preset: { flex: 1, padding: 10, borderRadius: Radius.md, borderWidth: 1, borderColor: Colors.border, alignItems: 'center', backgroundColor: Colors.surface },
  presetActive: { borderColor: Colors.accent, backgroundColor: '#4F8EF715' },
  presetMins: { fontSize: 12, fontWeight: '700', color: Colors.muted },
  presetSub: { fontSize: 10, color: Colors.muted, marginTop: 2 },
  statsRow: { flexDirection: 'row', marginHorizontal: Spacing.lg, marginBottom: Spacing.md, gap: 10 },
  statBox: { flex: 1, backgroundColor: Colors.card, borderRadius: Radius.md, padding: 14, alignItems: 'center', borderWidth: 1, borderColor: Colors.border },
  statVal: { fontSize: 24, fontWeight: '700' },
  statLbl: { fontSize: 11, color: Colors.muted, marginTop: 2 },
  logCard: { marginHorizontal: Spacing.lg, marginBottom: Spacing.lg, backgroundColor: Colors.card, borderRadius: Radius.lg, padding: Spacing.lg, borderWidth: 1, borderColor: Colors.border },
  logTitle: { fontSize: 14, fontWeight: '700', color: Colors.text, marginBottom: 12 },
  logRow: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 8, borderBottomWidth: 1, borderBottomColor: Colors.border + '60' },
  logLabel: { fontSize: 13, color: Colors.text },
  logDur: { fontSize: 13, color: Colors.green, fontWeight: '600' },
  logTotal: { flexDirection: 'row', justifyContent: 'space-between', paddingTop: 10, marginTop: 4 },
  logTotalLabel: { fontSize: 13, color: Colors.muted },
  logTotalVal: { fontSize: 15, fontWeight: '700' },
  emptyText: { fontSize: 13, color: Colors.muted, textAlign: 'center', paddingVertical: 12 },
});
