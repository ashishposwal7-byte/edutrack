// src/screens/student/TasksScreen.js
import React, { useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity, TextInput, StyleSheet, Modal, Alert } from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import { useData } from '../../context/DataContext';
import { Colors, Spacing, Radius } from '../../utils/theme';

export default function TasksScreen() {
  const { tasks, addTask, toggleTask } = useData();
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [showModal, setShowModal] = useState(false);
  const [title, setTitle] = useState('');
  const [subject, setSubject] = useState('Polity');
  const [priority, setPriority] = useState('medium');

  const dayTasks = tasks.filter(t => t.date === selectedDate);
  const done = dayTasks.filter(t => t.done).length;
  const pct = dayTasks.length ? Math.round(done / dayTasks.length * 100) : 0;
  const prColor = { high: Colors.red, medium: Colors.amber, low: Colors.green };

  const handleAdd = async () => {
    if (!title.trim()) { Alert.alert('Error', 'Enter task title'); return; }
    await addTask({ title, subject, priority, date: selectedDate });
    setTitle(''); setShowModal(false);
  };

  return (
    <View style={{ flex: 1, backgroundColor: Colors.bg }}>
      <LinearGradient colors={['#0f1a35', Colors.bg]} style={styles.header}>
        <View style={styles.headerRow}>
          <Text style={styles.headerTitle}>✅ Daily Tasks</Text>
          <TouchableOpacity onPress={() => setShowModal(true)}>
            <LinearGradient colors={['#4F8EF7', '#7C5CFC']} style={styles.addBtn}>
              <Text style={styles.addBtnText}>+ Add</Text>
            </LinearGradient>
          </TouchableOpacity>
        </View>
        <TextInput style={styles.dateInput} value={selectedDate} onChangeText={setSelectedDate} placeholder="YYYY-MM-DD" placeholderTextColor={Colors.muted} />
        {dayTasks.length > 0 && (
          <View style={styles.progressWrap}>
            <View style={styles.progressTrack}><View style={[styles.progressFill, { width: `${pct}%` }]} /></View>
            <Text style={styles.progressText}>{done}/{dayTasks.length} done · {pct}%</Text>
          </View>
        )}
      </LinearGradient>

      <ScrollView contentContainerStyle={{ padding: Spacing.lg }}>
        {dayTasks.length === 0 ? (
          <View style={styles.empty}>
            <Text style={{ fontSize: 40 }}>📋</Text>
            <Text style={styles.emptyTitle}>No tasks for this day</Text>
            <Text style={styles.emptySub}>Tap + Add to plan your study session</Text>
          </View>
        ) : dayTasks.map(t => (
          <TouchableOpacity key={t.id} style={[styles.taskCard, t.done && styles.taskDone]} onPress={() => toggleTask(t.id)}>
            <View style={[styles.taskCheck, t.done && styles.taskCheckDone]}><Text style={{ color: '#fff', fontSize: 12 }}>{t.done ? '✓' : ''}</Text></View>
            <View style={{ flex: 1 }}>
              <Text style={[styles.taskTitle, t.done && styles.taskTitleDone]}>{t.title}</Text>
              <Text style={styles.taskMeta}>{t.subject}</Text>
            </View>
            <View style={[styles.priorityBadge, { backgroundColor: prColor[t.priority] + '22' }]}>
              <Text style={[styles.priorityText, { color: prColor[t.priority] }]}>{t.priority}</Text>
            </View>
          </TouchableOpacity>
        ))}
      </ScrollView>

      <Modal visible={showModal} transparent animationType="slide">
        <View style={styles.overlay}>
          <View style={styles.modal}>
            <Text style={styles.modalTitle}>Add Task</Text>
            <TextInput style={styles.modalInput} value={title} onChangeText={setTitle} placeholder="Task title..." placeholderTextColor={Colors.muted} />
            <Text style={styles.modalLabel}>Priority</Text>
            <View style={styles.priorityRow}>
              {['high', 'medium', 'low'].map(p => (
                <TouchableOpacity key={p} style={[styles.priorityBtn, priority === p && { borderColor: prColor[p], backgroundColor: prColor[p] + '20' }]} onPress={() => setPriority(p)}>
                  <Text style={[styles.priorityBtnText, priority === p && { color: prColor[p] }]}>{p}</Text>
                </TouchableOpacity>
              ))}
            </View>
            <View style={styles.modalActions}>
              <TouchableOpacity style={styles.modalCancelBtn} onPress={() => setShowModal(false)}><Text style={{ color: Colors.muted }}>Cancel</Text></TouchableOpacity>
              <TouchableOpacity onPress={handleAdd}><LinearGradient colors={['#4F8EF7', '#7C5CFC']} style={styles.modalAddBtn}><Text style={{ color: '#fff', fontWeight: '700' }}>Add Task</Text></LinearGradient></TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const S2 = StyleSheet.create;
const styles = S2({
  header: { padding: Spacing.lg, paddingTop: Spacing.xxl },
  headerRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 },
  headerTitle: { fontSize: 22, fontWeight: '700', color: Colors.text },
  addBtn: { paddingHorizontal: 16, paddingVertical: 8, borderRadius: Radius.md },
  addBtnText: { color: '#fff', fontWeight: '700' },
  dateInput: { backgroundColor: Colors.surface, borderWidth: 1, borderColor: Colors.border, borderRadius: Radius.md, padding: 10, color: Colors.text, marginBottom: 12 },
  progressWrap: { gap: 6 },
  progressTrack: { height: 6, backgroundColor: Colors.border, borderRadius: 99, overflow: 'hidden' },
  progressFill: { height: '100%', backgroundColor: Colors.green, borderRadius: 99 },
  progressText: { fontSize: 12, color: Colors.muted },
  empty: { alignItems: 'center', paddingTop: 60, gap: 10 },
  emptyTitle: { fontSize: 18, fontWeight: '700', color: Colors.text },
  emptySub: { fontSize: 13, color: Colors.muted },
  taskCard: { flexDirection: 'row', alignItems: 'center', gap: 12, backgroundColor: Colors.card, borderRadius: Radius.md, padding: 14, marginBottom: 8, borderWidth: 1, borderColor: Colors.border },
  taskDone: { opacity: 0.6 },
  taskCheck: { width: 24, height: 24, borderRadius: 12, borderWidth: 2, borderColor: Colors.border, justifyContent: 'center', alignItems: 'center' },
  taskCheckDone: { backgroundColor: Colors.green, borderColor: Colors.green },
  taskTitle: { fontSize: 14, fontWeight: '600', color: Colors.text },
  taskTitleDone: { textDecorationLine: 'line-through', color: Colors.muted },
  taskMeta: { fontSize: 12, color: Colors.muted, marginTop: 2 },
  priorityBadge: { paddingHorizontal: 8, paddingVertical: 3, borderRadius: 99 },
  priorityText: { fontSize: 11, fontWeight: '700' },
  overlay: { flex: 1, backgroundColor: '#00000088', justifyContent: 'flex-end' },
  modal: { backgroundColor: Colors.card, borderTopLeftRadius: 20, borderTopRightRadius: 20, padding: 24, borderTopWidth: 1, borderColor: Colors.border },
  modalTitle: { fontSize: 18, fontWeight: '700', color: Colors.text, marginBottom: 16 },
  modalInput: { backgroundColor: Colors.surface, borderWidth: 1, borderColor: Colors.border, borderRadius: Radius.md, padding: 12, color: Colors.text, fontSize: 15, marginBottom: 14 },
  modalLabel: { fontSize: 12, color: Colors.muted, fontWeight: '600', marginBottom: 8 },
  priorityRow: { flexDirection: 'row', gap: 10, marginBottom: 20 },
  priorityBtn: { flex: 1, padding: 10, borderRadius: Radius.md, borderWidth: 1, borderColor: Colors.border, alignItems: 'center' },
  priorityBtnText: { fontWeight: '600', color: Colors.muted },
  modalActions: { flexDirection: 'row', justifyContent: 'flex-end', gap: 12 },
  modalCancelBtn: { padding: 12 },
  modalAddBtn: { paddingHorizontal: 20, paddingVertical: 12, borderRadius: Radius.md },
});

// ─────────────────────────────────────────────────
// src/screens/student/ProgressScreen.js
// ─────────────────────────────────────────────────
import React2 from 'react';
import { View as V2, Text as T2, ScrollView as SV2, StyleSheet as SS2 } from 'react-native';
import { useData as useD2 } from '../../context/DataContext';
import { Colors as C2, Spacing as SP2, Radius as R2 } from '../../utils/theme';

export function ProgressScreen() {
  const { topics, sessions, scores, tasks, totalStudyHours, kilo_pct, topicsDone, topicsTotal, topicsPct, avgScore, weekHours } = useD2();
  const grouped = {};
  topics.forEach(t => { if (!grouped[t.subject]) grouped[t.subject] = { done: 0, total: 0 }; grouped[t.subject].total++; if (t.status === 'done') grouped[t.subject].done++; });
  const best = scores.length ? Math.max(...scores.map(s => s.score)) : null;
  const colors = [C2.accent, C2.accent2, C2.green, C2.amber, C2.red, C2.pink];
  const s3 = SS2.create({
    container: { flex: 1, backgroundColor: C2.bg },
    title: { fontSize: 22, fontWeight: '700', color: C2.text, margin: SP2.lg },
    card: { marginHorizontal: SP2.lg, marginBottom: SP2.md, backgroundColor: C2.card, borderRadius: R2.lg, padding: SP2.lg, borderWidth: 1, borderColor: C2.border },
    ct: { fontSize: 14, fontWeight: '700', color: C2.text, marginBottom: 14 },
    sg: { display: 'flex', flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginBottom: SP2.md },
    scard: { backgroundColor: C2.card, borderRadius: R2.md, padding: 14, borderWidth: 1, borderColor: C2.border, width: '47%' },
    sv: { fontSize: 22, fontWeight: '700' }, sl: { fontSize: 10, color: C2.muted, textTransform: 'uppercase', marginTop: 3 },
    pbar: { height: 6, backgroundColor: C2.border, borderRadius: 99, overflow: 'hidden', marginTop: 6 },
    pfill: { height: '100%', borderRadius: 99 },
    subjRow: { marginBottom: 12 },
    subjHdr: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 4 },
    subjName: { fontSize: 13, fontWeight: '600', color: C2.text },
    subjPct: { fontSize: 12, color: C2.muted },
  });
  return (
    <SV2 style={s3.container} showsVerticalScrollIndicator={false}>
      <T2 style={s3.title}>📈 Progress Report</T2>
      <V2 style={s3.sg}>
        {[
          { v: topicsPct + '%', l: 'Overall Progress', c: C2.accent },
          { v: totalStudyHours.toFixed(1) + 'h', l: 'Total Study Time', c: C2.green },
          { v: sessions.length, l: 'Sessions Logged', c: C2.accent2 },
          { v: avgScore !== null ? avgScore + '%' : '—', l: 'Avg Test Score', c: C2.amber },
          { v: best !== null ? best + '%' : '—', l: 'Best Score', c: C2.pink },
          { v: tasks.filter(t => t.done).length, l: 'Tasks Done', c: C2.red },
        ].map((s, i) => (
          <V2 key={i} style={s3.scard}>
            <T2 style={[s3.sv, { color: s.c }]}>{s.v}</T2>
            <T2 style={s3.sl}>{s.l}</T2>
          </V2>
        ))}
      </V2>
      <V2 style={s3.card}>
        <T2 style={s3.ct}>📚 Subject Progress</T2>
        {Object.entries(grouped).map(([subj, v], i) => {
          const p = Math.round(v.done / v.total * 100);
          return (
            <V2 key={subj} style={s3.subjRow}>
              <V2 style={s3.subjHdr}><T2 style={s3.subjName}>{subj}</T2><T2 style={s3.subjPct}>{v.done}/{v.total} · {p}%</T2></V2>
              <V2 style={s3.pbar}><V2 style={[s3.pfill, { width: p + '%', backgroundColor: colors[i % colors.length] }]} /></V2>
            </V2>
          );
        })}
      </V2>
      <V2 style={s3.card}>
        <T2 style={s3.ct}>⚡ 1000-Hour Progress</T2>
        <T2 style={{ fontSize: 32, fontWeight: '700', color: C2.accent }}>{totalStudyHours.toFixed(1)}<T2 style={{ fontSize: 16, color: C2.muted }}> / 1,000 hrs</T2></T2>
        <V2 style={[s3.pbar, { height: 10, marginTop: 10 }]}><V2 style={[s3.pfill, { width: kilo_pct + '%', backgroundColor: C2.accent2 }]} /></V2>
        <T2 style={{ color: C2.muted, fontSize: 12, marginTop: 6 }}>{kilo_pct.toFixed(1)}% of mastery goal achieved</T2>
      </V2>
      <V2 style={{ height: 80 }} />
    </SV2>
  );
}
export default ProgressScreen;

// ─────────────────────────────────────────────────
// src/screens/student/ScoresScreen.js
// ─────────────────────────────────────────────────
export function ScoresScreen() {
  const [showAdd, setShowAdd] = React2.useState(false);
  const [form, setForm] = React2.useState({ name: '', subject: 'Full Mock Test', score: '', max: '100', time: '', rank: '', notes: '' });
  const { scores, addScore } = useD2();
  const avg = scores.length ? Math.round(scores.reduce((a, s) => a + s.score, 0) / scores.length) : null;
  const best = scores.length ? Math.max(...scores.map(s => s.score)) : null;
  const bestRank = scores.filter(s => s.rank).length ? Math.min(...scores.filter(s => s.rank).map(s => s.rank)) : null;
  const scoreColor = (s) => s >= 80 ? C2.green : s >= 60 ? C2.amber : C2.red;
  const s4 = SS2.create({
    container: { flex: 1, backgroundColor: C2.bg },
    hdr: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', margin: SP2.lg },
    title: { fontSize: 22, fontWeight: '700', color: C2.text },
    addBtn: { paddingHorizontal: 16, paddingVertical: 8, borderRadius: R2.md },
    sg: { flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginHorizontal: SP2.lg, marginBottom: SP2.md },
    scard: { backgroundColor: C2.card, borderRadius: R2.md, padding: 14, borderWidth: 1, borderColor: C2.border, width: '47%' },
    sv: { fontSize: 22, fontWeight: '700' }, sl: { fontSize: 10, color: C2.muted, textTransform: 'uppercase', marginTop: 3 },
    scoreCard: { flexDirection: 'row', alignItems: 'center', gap: 12, marginHorizontal: SP2.lg, marginBottom: 8, backgroundColor: C2.card, borderRadius: R2.md, padding: 14, borderWidth: 1, borderColor: C2.border },
    scoreCircle: { width: 48, height: 48, borderRadius: 24, justifyContent: 'center', alignItems: 'center' },
    scoreName: { fontSize: 14, fontWeight: '600', color: C2.text },
    scoreMeta: { fontSize: 12, color: C2.muted, marginTop: 2 },
    scorePct: { fontSize: 18, fontWeight: '700', marginLeft: 'auto' },
    overlay: { flex: 1, backgroundColor: '#00000088', justifyContent: 'flex-end' },
    modal: { backgroundColor: C2.card, borderTopLeftRadius: 20, borderTopRightRadius: 20, padding: 24, borderTopWidth: 1, borderColor: C2.border },
    modalTitle: { fontSize: 18, fontWeight: '700', color: C2.text, marginBottom: 16 },
    inp: { backgroundColor: C2.surface, borderWidth: 1, borderColor: C2.border, borderRadius: R2.md, padding: 10, color: C2.text, marginBottom: 10 },
    row2: { flexDirection: 'row', gap: 10 },
    actions: { flexDirection: 'row', justifyContent: 'flex-end', gap: 12, marginTop: 8 },
    cancelBtn: { padding: 12 },
    saveBtn: { paddingHorizontal: 20, paddingVertical: 12, borderRadius: R2.md },
  });
  const handleSave = async () => {
    if (!form.name || !form.score) { return; }
    await addScore({ name: form.name, subject: form.subject, score: Math.round(parseInt(form.score) / parseInt(form.max || 100) * 100), max: parseInt(form.max) || 100, time: parseInt(form.time) || null, rank: parseInt(form.rank) || null, notes: form.notes });
    setForm({ name: '', subject: 'Full Mock Test', score: '', max: '100', time: '', rank: '', notes: '' });
    setShowAdd(false);
  };
  return (
    <SV2 style={s4.container} showsVerticalScrollIndicator={false}>
      <V2 style={s4.hdr}>
        <T2 style={s4.title}>🏆 Test Scores</T2>
        <TouchableOpacity onPress={() => setShowAdd(true)}><LinearGradient colors={['#4F8EF7', '#7C5CFC']} style={s4.addBtn}><T2 style={{ color: '#fff', fontWeight: '700' }}>+ Log Score</T2></LinearGradient></TouchableOpacity>
      </V2>
      <V2 style={s4.sg}>
        {[{ v: avg !== null ? avg + '%' : '—', l: 'Average Score', c: C2.amber }, { v: best !== null ? best + '%' : '—', l: 'Best Score', c: C2.green }, { v: scores.length, l: 'Tests Taken', c: C2.accent }, { v: bestRank !== null ? '#' + bestRank : '—', l: 'Best Rank', c: C2.accent2 }].map((s, i) => (
          <V2 key={i} style={s4.scard}><T2 style={[s4.sv, { color: s.c }]}>{s.v}</T2><T2 style={s4.sl}>{s.l}</T2></V2>
        ))}
      </V2>
      {[...scores].sort((a, b) => (b.date || 0) - (a.date || 0)).map(s => (
        <V2 key={s.id} style={s4.scoreCard}>
          <V2 style={[s4.scoreCircle, { backgroundColor: scoreColor(s.score) + '22' }]}><T2 style={[{ fontWeight: '700', color: scoreColor(s.score) }]}>{s.score}</T2></V2>
          <V2 style={{ flex: 1 }}><T2 style={s4.scoreName}>{s.name}</T2><T2 style={s4.scoreMeta}>{s.subject}{s.rank ? ` · Rank #${s.rank}` : ''}{s.time ? ` · ${s.time}m` : ''}</T2></V2>
          <T2 style={[s4.scorePct, { color: scoreColor(s.score) }]}>{s.score}%</T2>
        </V2>
      ))}
      {scores.length === 0 && <V2 style={{ alignItems: 'center', padding: 40 }}><T2 style={{ fontSize: 40 }}>🏆</T2><T2 style={{ color: C2.muted, marginTop: 10 }}>No scores yet. Log your first test!</T2></V2>}
      <V2 style={{ height: 80 }} />
      <Modal visible={showAdd} transparent animationType="slide">
        <V2 style={s4.overlay}>
          <V2 style={s4.modal}>
            <T2 style={s4.modalTitle}>Log Test Score 🏆</T2>
            <TextInput style={s4.inp} value={form.name} onChangeText={v => setForm(f => ({ ...f, name: v }))} placeholder="Test name..." placeholderTextColor={C2.muted} />
            <V2 style={s4.row2}>
              <TextInput style={[s4.inp, { flex: 1 }]} value={form.score} onChangeText={v => setForm(f => ({ ...f, score: v }))} placeholder="Score" placeholderTextColor={C2.muted} keyboardType="numeric" />
              <TextInput style={[s4.inp, { flex: 1 }]} value={form.max} onChangeText={v => setForm(f => ({ ...f, max: v }))} placeholder="Max marks" placeholderTextColor={C2.muted} keyboardType="numeric" />
            </V2>
            <V2 style={s4.row2}>
              <TextInput style={[s4.inp, { flex: 1 }]} value={form.time} onChangeText={v => setForm(f => ({ ...f, time: v }))} placeholder="Time (mins)" placeholderTextColor={C2.muted} keyboardType="numeric" />
              <TextInput style={[s4.inp, { flex: 1 }]} value={form.rank} onChangeText={v => setForm(f => ({ ...f, rank: v }))} placeholder="Rank" placeholderTextColor={C2.muted} keyboardType="numeric" />
            </V2>
            <TextInput style={s4.inp} value={form.notes} onChangeText={v => setForm(f => ({ ...f, notes: v }))} placeholder="Notes..." placeholderTextColor={C2.muted} />
            <V2 style={s4.actions}>
              <TouchableOpacity style={s4.cancelBtn} onPress={() => setShowAdd(false)}><T2 style={{ color: C2.muted }}>Cancel</T2></TouchableOpacity>
              <TouchableOpacity onPress={handleSave}><LinearGradient colors={['#FBBF24', '#F59E0B']} style={s4.saveBtn}><T2 style={{ color: '#000', fontWeight: '700' }}>Save Score</T2></LinearGradient></TouchableOpacity>
            </V2>
          </V2>
        </V2>
      </Modal>
    </SV2>
  );
}

// ─────────────────────────────────────────────────
// Placeholder screens that navigate to full pages
// ─────────────────────────────────────────────────
const PlaceholderScreen = ({ title, emoji, description }) => (
  <V2 style={{ flex: 1, backgroundColor: C2.bg, justifyContent: 'center', alignItems: 'center', padding: 24 }}>
    <T2 style={{ fontSize: 50, marginBottom: 16 }}>{emoji}</T2>
    <T2 style={{ fontSize: 22, fontWeight: '700', color: C2.text, marginBottom: 8 }}>{title}</T2>
    <T2 style={{ fontSize: 14, color: C2.muted, textAlign: 'center' }}>{description}</T2>
  </V2>
);

export const StreakScreen = () => <PlaceholderScreen title="Study Streak" emoji="🔥" description="Track your study consistency — coming in Phase 3 with full calendar and milestone view." />;
export const AssignmentsScreen = () => { const { assignments, completeAssignment } = useD2(); return (
  <SV2 style={{ flex: 1, backgroundColor: C2.bg }} showsVerticalScrollIndicator={false}>
    <T2 style={{ fontSize: 22, fontWeight: '700', color: C2.text, margin: SP2.lg }}>📌 Assignments</T2>
    {assignments.filter(a => !a.done).map(a => {
      const c = { high: C2.red, medium: C2.amber, low: C2.green }[a.priority] || C2.border;
      return (
        <V2 key={a.id} style={{ marginHorizontal: SP2.lg, marginBottom: 8, backgroundColor: C2.card, borderRadius: R2.md, padding: 14, borderWidth: 1, borderColor: C2.border, flexDirection: 'row', gap: 10 }}>
          <V2 style={{ width: 4, backgroundColor: c, borderRadius: 99 }} />
          <V2 style={{ flex: 1 }}><T2 style={{ fontSize: 14, fontWeight: '600', color: C2.text }}>{a.title}</T2><T2 style={{ fontSize: 12, color: C2.muted, marginTop: 2 }}>From: {a.from} · Due: {a.due}</T2></V2>
          <TouchableOpacity onPress={() => completeAssignment(a.id)} style={{ backgroundColor: C2.green, paddingHorizontal: 10, paddingVertical: 6, borderRadius: R2.sm }}><T2 style={{ color: '#000', fontWeight: '700', fontSize: 11 }}>Done</T2></TouchableOpacity>
        </V2>
      );
    })}
    {assignments.filter(a => !a.done).length === 0 && <PlaceholderScreen title="All Done!" emoji="🎉" description="No pending assignments." />}
    <V2 style={{ height: 80 }} />
  </SV2>
); };
export const ScheduleScreen = () => <PlaceholderScreen title="Weekly Schedule" emoji="📅" description="Your AI-generated study schedule appears here." />;
export const ResourcesScreen = () => <PlaceholderScreen title="Resources" emoji="🎥" description="Curated YouTube channels and books for your exam." />;
export const SyllabusScreen = () => { const { topics, updateTopicStatus } = useD2(); return <ExamSyllabusScreen />; };
