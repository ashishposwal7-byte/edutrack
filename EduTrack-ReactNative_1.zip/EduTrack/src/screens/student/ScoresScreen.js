export { ScoresScreen as default } from '../AllStudentScreens';
