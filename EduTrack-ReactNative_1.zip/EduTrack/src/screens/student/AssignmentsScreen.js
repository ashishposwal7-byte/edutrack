export { AssignmentsScreen as default } from '../AllStudentScreens';
