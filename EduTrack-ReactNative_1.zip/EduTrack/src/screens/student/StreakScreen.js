export { StreakScreen as default } from '../AllStudentScreens';
