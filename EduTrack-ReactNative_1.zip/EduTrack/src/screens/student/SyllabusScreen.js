export { SyllabusScreen as default } from '../AllStudentScreens';
