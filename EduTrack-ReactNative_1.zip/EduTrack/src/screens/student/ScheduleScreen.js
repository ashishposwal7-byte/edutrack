export { ScheduleScreen as default } from '../AllStudentScreens';
