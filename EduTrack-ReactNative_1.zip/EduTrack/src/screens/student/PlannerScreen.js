// src/screens/student/PlannerScreen.js
import React, { useState, useRef } from 'react';
import { View, Text, TextInput, TouchableOpacity, FlatList, StyleSheet, KeyboardAvoidingView, Platform, ActivityIndicator } from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import { useAuth } from '../../context/AuthContext';
import { useData } from '../../context/DataContext';
import { Colors, Spacing, Radius } from '../../utils/theme';

const QUICK_PROMPTS = [
  '📅 Create a 2-week plan for Polity',
  '🎥 Best YouTube channels for UPSC History',
  '📖 Books I need for Economy GS3',
  '🔁 What should I study next?',
  '⏱️ How many hours should I study daily?',
];

export default function PlannerScreen() {
  const { profile } = useAuth();
  const { topics } = useData();
  const [messages, setMessages] = useState([
    {
      id: '0', role: 'bot',
      text: `Hi ${(profile?.name || 'there').split(' ')[0]}! 👋 I'm your AI study planner.\n\nI know you're preparing for **${profile?.examKey || profile?.subject || 'your exam'}**.\n\nTry asking me:\n• Create a weekly schedule\n• Best resources for a subject\n• What to study next\n• How to improve weak areas`,
    },
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const flatRef = useRef(null);

  const done = topics.filter(t => t.status === 'done').map(t => t.name).join(', ') || 'none yet';
  const pending = topics.filter(t => t.status !== 'done').map(t => t.name).slice(0, 10).join(', ') || 'none added';

  const send = async (text) => {
    if (!text.trim() || loading) return;
    const userMsg = { id: Date.now().toString(), role: 'user', text };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setLoading(true);

    try {
      const res = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          model: 'claude-sonnet-4-6',
          max_tokens: 1000,
          system: `You are an expert AI study planner for Indian competitive exam students.
Student: ${profile?.name}, preparing for: ${profile?.examKey || profile?.subject || 'competitive exams'}.
Topics completed: ${done}.
Topics pending: ${pending}.
Give personalized schedules, recommend YouTube channels (Mrunal, Study IQ, Vision IAS, Unacademy), suggest books (NCERT, Laxmikant, Ramesh Singh etc).
Be concise, structured, use emojis. Be encouraging and specific. Format nicely for mobile reading.`,
          messages: [{ role: 'user', content: text }],
        }),
      });
      const data = await res.json();
      const reply = data.content?.[0]?.text || "Sorry, I couldn't get a response. Please try again.";
      setMessages(prev => [...prev, { id: (Date.now() + 1).toString(), role: 'bot', text: reply }]);
    } catch (e) {
      setMessages(prev => [...prev, { id: (Date.now() + 1).toString(), role: 'bot', text: '⚠️ Connection error. Please check your internet and try again.' }]);
    }
    setLoading(false);
    setTimeout(() => flatRef.current?.scrollToEnd({ animated: true }), 200);
  };

  const renderMsg = ({ item }) => {
    const isUser = item.role === 'user';
    return (
      <View style={[styles.msgRow, isUser && styles.msgRowUser]}>
        <View style={[styles.avatar, isUser && styles.avatarUser]}>
          <Text style={{ fontSize: 14 }}>{isUser ? (profile?.name?.[0] || 'U') : '🤖'}</Text>
        </View>
        <View style={[styles.bubble, isUser ? styles.bubbleUser : styles.bubbleBot]}>
          <Text style={[styles.bubbleText, isUser && { color: '#fff' }]}>{item.text}</Text>
        </View>
      </View>
    );
  };

  return (
    <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined} keyboardVerticalOffset={90}>
      <View style={styles.container}>
        <LinearGradient colors={['#4F8EF7', '#7C5CFC']} style={styles.header}>
          <Text style={styles.headerTitle}>🤖 AI Study Planner</Text>
          <Text style={styles.headerSub}>Powered by Claude AI</Text>
        </LinearGradient>

        {/* Quick prompts */}
        {messages.length <= 1 && (
          <View>
            <Text style={styles.quickLabel}>Quick prompts</Text>
            {QUICK_PROMPTS.map((q, i) => (
              <TouchableOpacity key={i} style={styles.quickBtn} onPress={() => send(q)}>
                <Text style={styles.quickBtnText}>{q}</Text>
              </TouchableOpacity>
            ))}
          </View>
        )}

        <FlatList ref={flatRef} data={messages} renderItem={renderMsg} keyExtractor={i => i.id} style={styles.msgs} contentContainerStyle={{ padding: 16, gap: 12 }} showsVerticalScrollIndicator={false} />

        {loading && (
          <View style={styles.typingRow}>
            <View style={styles.avatar}><Text>🤖</Text></View>
            <View style={styles.typingBubble}>
              <ActivityIndicator size="small" color={Colors.accent} />
              <Text style={styles.typingText}>Thinking...</Text>
            </View>
          </View>
        )}

        <View style={styles.inputRow}>
          <TextInput style={styles.input} value={input} onChangeText={setInput} placeholder="Ask your AI planner..." placeholderTextColor={Colors.muted} multiline maxLength={500} onSubmitEditing={() => send(input)} />
          <TouchableOpacity onPress={() => send(input)} disabled={loading || !input.trim()} style={{ opacity: loading || !input.trim() ? 0.5 : 1 }}>
            <LinearGradient colors={['#4F8EF7', '#7C5CFC']} style={styles.sendBtn}>
              <Text style={{ color: '#fff', fontSize: 18 }}>➤</Text>
            </LinearGradient>
          </TouchableOpacity>
        </View>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.bg },
  header: { padding: Spacing.lg, paddingTop: Spacing.xl },
  headerTitle: { fontSize: 20, fontWeight: '700', color: '#fff' },
  headerSub: { fontSize: 12, color: '#ffffff90', marginTop: 2 },
  quickLabel: { fontSize: 12, color: Colors.muted, fontWeight: '600', marginHorizontal: 16, marginTop: 12, marginBottom: 6 },
  quickBtn: { marginHorizontal: 16, marginBottom: 6, padding: 12, backgroundColor: Colors.card, borderRadius: Radius.md, borderWidth: 1, borderColor: Colors.border },
  quickBtnText: { fontSize: 13, color: Colors.text },
  msgs: { flex: 1 },
  msgRow: { flexDirection: 'row', gap: 8, alignItems: 'flex-start' },
  msgRowUser: { flexDirection: 'row-reverse' },
  avatar: { width: 32, height: 32, borderRadius: 16, backgroundColor: Colors.accent, justifyContent: 'center', alignItems: 'center' },
  avatarUser: { backgroundColor: Colors.border },
  bubble: { maxWidth: '80%', borderRadius: 14, padding: 12 },
  bubbleBot: { backgroundColor: Colors.card, borderWidth: 1, borderColor: Colors.border, borderTopLeftRadius: 4 },
  bubbleUser: { backgroundColor: Colors.accent, borderTopRightRadius: 4 },
  bubbleText: { fontSize: 14, color: Colors.text, lineHeight: 21 },
  typingRow: { flexDirection: 'row', gap: 8, padding: 16, alignItems: 'center' },
  typingBubble: { flexDirection: 'row', gap: 8, backgroundColor: Colors.card, borderRadius: 12, padding: 12, borderWidth: 1, borderColor: Colors.border },
  typingText: { fontSize: 13, color: Colors.muted },
  inputRow: { flexDirection: 'row', gap: 8, padding: 12, backgroundColor: Colors.card, borderTopWidth: 1, borderTopColor: Colors.border },
  input: { flex: 1, backgroundColor: Colors.surface, borderWidth: 1, borderColor: Colors.border, borderRadius: Radius.md, padding: 10, color: Colors.text, fontSize: 14, maxHeight: 100 },
  sendBtn: { width: 44, height: 44, borderRadius: Radius.md, justifyContent: 'center', alignItems: 'center' },
});
