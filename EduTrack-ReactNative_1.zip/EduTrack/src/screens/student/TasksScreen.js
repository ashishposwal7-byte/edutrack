import React from 'react';
import { View, Text, ScrollView, TouchableOpacity, TextInput, StyleSheet, Modal, Alert } from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import { useData } from '../../context/DataContext';
import { Colors, Spacing, Radius } from '../../utils/theme';

const prColor = { high: '#F87171', medium: '#FBBF24', low: '#34D399' };

export default function TasksScreen() {
  const { tasks, addTask, toggleTask } = useData();
  const [selectedDate, setSelectedDate] = React.useState(new Date().toISOString().split('T')[0]);
  const [showModal, setShowModal] = React.useState(false);
  const [title, setTitle] = React.useState('');
  const [subject, setSubject] = React.useState('General');
  const [priority, setPriority] = React.useState('medium');

  const dayTasks = tasks.filter(t => t.date === selectedDate);
  const done = dayTasks.filter(t => t.done).length;
  const pct = dayTasks.length ? Math.round(done / dayTasks.length * 100) : 0;

  const handleAdd = async () => {
    if (!title.trim()) { Alert.alert('Error', 'Enter task title'); return; }
    await addTask({ title, subject, priority, date: selectedDate });
    setTitle(''); setShowModal(false);
  };

  return (
    <View style={{ flex: 1, backgroundColor: Colors.bg }}>
      <LinearGradient colors={['#0f1a35', Colors.bg]} style={{ padding: Spacing.lg, paddingTop: Spacing.xxl }}>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
          <Text style={{ fontSize: 22, fontWeight: '700', color: Colors.text }}>✅ Daily Tasks</Text>
          <TouchableOpacity onPress={() => setShowModal(true)}>
            <LinearGradient colors={['#4F8EF7', '#7C5CFC']} style={{ paddingHorizontal: 16, paddingVertical: 8, borderRadius: 10 }}>
              <Text style={{ color: '#fff', fontWeight: '700' }}>+ Add</Text>
            </LinearGradient>
          </TouchableOpacity>
        </View>
        <TextInput style={{ backgroundColor: Colors.surface, borderWidth: 1, borderColor: Colors.border, borderRadius: 10, padding: 10, color: Colors.text, marginBottom: 12 }} value={selectedDate} onChangeText={setSelectedDate} placeholder="YYYY-MM-DD" placeholderTextColor={Colors.muted} />
        {dayTasks.length > 0 && (
          <View>
            <View style={{ height: 6, backgroundColor: Colors.border, borderRadius: 99, overflow: 'hidden', marginBottom: 6 }}>
              <View style={{ width: pct + '%', height: '100%', backgroundColor: Colors.green, borderRadius: 99 }} />
            </View>
            <Text style={{ fontSize: 12, color: Colors.muted }}>{done}/{dayTasks.length} done · {pct}%</Text>
          </View>
        )}
      </LinearGradient>
      <ScrollView contentContainerStyle={{ padding: Spacing.lg }}>
        {dayTasks.length === 0 ? (
          <View style={{ alignItems: 'center', paddingTop: 60, gap: 10 }}>
            <Text style={{ fontSize: 40 }}>📋</Text>
            <Text style={{ fontSize: 18, fontWeight: '700', color: Colors.text }}>No tasks for this day</Text>
            <Text style={{ fontSize: 13, color: Colors.muted }}>Tap + Add to plan your study session</Text>
          </View>
        ) : dayTasks.map(t => (
          <TouchableOpacity key={t.id} style={{ flexDirection: 'row', alignItems: 'center', gap: 12, backgroundColor: Colors.card, borderRadius: 12, padding: 14, marginBottom: 8, borderWidth: 1, borderColor: Colors.border, opacity: t.done ? 0.7 : 1 }} onPress={() => toggleTask(t.id)}>
            <View style={{ width: 24, height: 24, borderRadius: 12, borderWidth: 2, borderColor: t.done ? Colors.green : Colors.border, backgroundColor: t.done ? Colors.green : 'transparent', justifyContent: 'center', alignItems: 'center' }}>
              {t.done && <Text style={{ color: '#fff', fontSize: 12 }}>✓</Text>}
            </View>
            <View style={{ flex: 1 }}>
              <Text style={{ fontSize: 14, fontWeight: '600', color: Colors.text, textDecorationLine: t.done ? 'line-through' : 'none' }}>{t.title}</Text>
              <Text style={{ fontSize: 12, color: Colors.muted, marginTop: 2 }}>{t.subject}</Text>
            </View>
            <View style={{ paddingHorizontal: 8, paddingVertical: 3, borderRadius: 99, backgroundColor: (prColor[t.priority] || Colors.border) + '22' }}>
              <Text style={{ fontSize: 11, fontWeight: '700', color: prColor[t.priority] || Colors.muted }}>{t.priority}</Text>
            </View>
          </TouchableOpacity>
        ))}
      </ScrollView>
      <Modal visible={showModal} transparent animationType="slide">
        <View style={{ flex: 1, backgroundColor: '#00000088', justifyContent: 'flex-end' }}>
          <View style={{ backgroundColor: Colors.card, borderTopLeftRadius: 20, borderTopRightRadius: 20, padding: 24, borderTopWidth: 1, borderColor: Colors.border }}>
            <Text style={{ fontSize: 18, fontWeight: '700', color: Colors.text, marginBottom: 16 }}>Add Task</Text>
            <TextInput style={{ backgroundColor: Colors.surface, borderWidth: 1, borderColor: Colors.border, borderRadius: 10, padding: 12, color: Colors.text, marginBottom: 12 }} value={title} onChangeText={setTitle} placeholder="What do you need to do?" placeholderTextColor={Colors.muted} />
            <TextInput style={{ backgroundColor: Colors.surface, borderWidth: 1, borderColor: Colors.border, borderRadius: 10, padding: 12, color: Colors.text, marginBottom: 14 }} value={subject} onChangeText={setSubject} placeholder="Subject (e.g. Polity)" placeholderTextColor={Colors.muted} />
            <Text style={{ fontSize: 11, color: Colors.muted, fontWeight: '600', marginBottom: 8 }}>PRIORITY</Text>
            <View style={{ flexDirection: 'row', gap: 10, marginBottom: 20 }}>
              {['high', 'medium', 'low'].map(p => (
                <TouchableOpacity key={p} style={{ flex: 1, padding: 10, borderRadius: 10, borderWidth: 1, borderColor: priority === p ? (prColor[p] || Colors.border) : Colors.border, backgroundColor: priority === p ? (prColor[p] + '20') : 'transparent', alignItems: 'center' }} onPress={() => setPriority(p)}>
                  <Text style={{ fontWeight: '600', color: priority === p ? prColor[p] : Colors.muted }}>{p}</Text>
                </TouchableOpacity>
              ))}
            </View>
            <View style={{ flexDirection: 'row', justifyContent: 'flex-end', gap: 12 }}>
              <TouchableOpacity style={{ padding: 12 }} onPress={() => setShowModal(false)}><Text style={{ color: Colors.muted }}>Cancel</Text></TouchableOpacity>
              <TouchableOpacity onPress={handleAdd}>
                <LinearGradient colors={['#4F8EF7', '#7C5CFC']} style={{ paddingHorizontal: 20, paddingVertical: 12, borderRadius: 10 }}>
                  <Text style={{ color: '#fff', fontWeight: '700' }}>Add Task</Text>
                </LinearGradient>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}
