// src/screens/chat/ChatScreen.js
import React, { useEffect } from 'react';
import { View, Text, FlatList, TouchableOpacity, StyleSheet } from 'react-native';
import { useAuth } from '../../context/AuthContext';
import { useData } from '../../context/DataContext';
import { Colors, Spacing, Radius } from '../../utils/theme';

export default function ChatScreen({ navigation }) {
  const { profile } = useAuth();
  const { students } = useData();
  const isTeacher = profile?.role === 'teacher';

  const contacts = isTeacher
    ? students.map(s => ({ uid: s.id, name: s.name, role: 'Student', sub: s.subject || '' }))
    : [{ uid: 'teacher', name: 'Prof. Sharma', role: 'Teacher', sub: 'Your teacher' }];

  return (
    <View style={{ flex: 1, backgroundColor: Colors.bg }}>
      <Text style={{ fontSize: 22, fontWeight: '700', color: Colors.text, margin: Spacing.lg }}>💬 Messages</Text>
      <FlatList
        data={contacts}
        keyExtractor={i => i.uid}
        renderItem={({ item }) => (
          <TouchableOpacity style={styles.contactRow} onPress={() => navigation.navigate('Conversation', { contact: item })}>
            <View style={[styles.avatar, { backgroundColor: isTeacher ? '#7C5CFC20' : '#4F8EF720' }]}>
              <Text style={{ fontSize: 18, color: isTeacher ? Colors.accent2 : Colors.accent }}>{item.name[0]}</Text>
            </View>
            <View style={{ flex: 1 }}>
              <Text style={styles.contactName}>{item.name}</Text>
              <Text style={styles.contactRole}>{item.role}{item.sub ? ` · ${item.sub}` : ''}</Text>
            </View>
            <Text style={{ color: Colors.accent, fontSize: 18 }}>›</Text>
          </TouchableOpacity>
        )}
        contentContainerStyle={{ padding: Spacing.lg }}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  contactRow: { flexDirection: 'row', alignItems: 'center', gap: 12, backgroundColor: Colors.card, borderRadius: Radius.md, padding: 14, marginBottom: 8, borderWidth: 1, borderColor: Colors.border },
  avatar: { width: 44, height: 44, borderRadius: 22, justifyContent: 'center', alignItems: 'center' },
  contactName: { fontSize: 15, fontWeight: '600', color: Colors.text },
  contactRole: { fontSize: 12, color: Colors.muted, marginTop: 2 },
});

// ─────────────────────────────────────────────────
// src/screens/chat/ConversationScreen.js
// ─────────────────────────────────────────────────
import React2, { useState, useRef, useEffect as UE2 } from 'react';
import { View as V2, Text as T2, TextInput, FlatList as FL2, TouchableOpacity as TO2, StyleSheet as SS2, KeyboardAvoidingView, Platform } from 'react-native';
import { useAuth as UA2 } from '../../context/AuthContext';
import { useData as UD2 } from '../../context/DataContext';
import { Colors as C2, Spacing as SP2, Radius as R2 } from '../../utils/theme';
import LinearGradient from 'react-native-linear-gradient';

export function ConversationScreen({ navigation, route }) {
  const { contact } = route.params;
  const { user } = UA2();
  const { messages, loadMessages, sendMessage } = UD2();
  const [text, setText] = useState('');
  const flatRef = useRef(null);
  const msgs = messages[contact.uid] || [];

  UE2(() => { navigation.setOptions({ title: contact.name }); loadMessages(contact.uid); }, [contact.uid]);

  const send = async () => {
    if (!text.trim()) return;
    await sendMessage(contact.uid, text.trim());
    setText('');
    setTimeout(() => flatRef.current?.scrollToEnd({ animated: true }), 150);
  };

  const s = SS2.create({
    container: { flex: 1, backgroundColor: C2.bg },
    msgRow: { marginBottom: 8 },
    mine: { alignItems: 'flex-end' },
    theirs: { alignItems: 'flex-start' },
    bubble: { maxWidth: '80%', padding: 12, borderRadius: 14 },
    bubbleMine: { borderBottomRightRadius: 4 },
    bubbleTheirs: { backgroundColor: C2.card, borderWidth: 1, borderColor: C2.border, borderBottomLeftRadius: 4 },
    bubbleTxt: { fontSize: 14, lineHeight: 20 },
    time: { fontSize: 10, color: C2.muted, marginTop: 3 },
    inputRow: { flexDirection: 'row', gap: 8, padding: 12, backgroundColor: C2.card, borderTopWidth: 1, borderTopColor: C2.border },
    input: { flex: 1, backgroundColor: C2.surface, borderWidth: 1, borderColor: C2.border, borderRadius: R2.md, padding: 10, color: C2.text, fontSize: 14 },
    sendBtn: { width: 44, height: 44, borderRadius: R2.md, justifyContent: 'center', alignItems: 'center' },
  });

  return (
    <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined} keyboardVerticalOffset={90}>
      <V2 style={s.container}>
        <FL2 ref={flatRef} data={msgs} keyExtractor={i => i.id} style={{ flex: 1 }} contentContainerStyle={{ padding: 16 }}
          renderItem={({ item }) => {
            const isMine = item.from === user?.uid;
            return (
              <V2 style={[s.msgRow, isMine ? s.mine : s.theirs]}>
                <V2 style={[s.bubble, isMine ? s.bubbleMine : s.bubbleTheirs]}>
                  {isMine
                    ? <LinearGradient colors={['#4F8EF7', '#7C5CFC']} style={{ borderRadius: 10, padding: 12 }}><T2 style={[s.bubbleTxt, { color: '#fff' }]}>{item.text}</T2></LinearGradient>
                    : <T2 style={[s.bubbleTxt, { color: C2.text }]}>{item.text}</T2>}
                  <T2 style={s.time}>{new Date(item.time).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })}</T2>
                </V2>
              </V2>
            );
          }}
          onContentSizeChange={() => flatRef.current?.scrollToEnd({ animated: false })}
        />
        <V2 style={s.inputRow}>
          <TextInput style={s.input} value={text} onChangeText={setText} placeholder="Type a message..." placeholderTextColor={C2.muted} />
          <TO2 onPress={send}><LinearGradient colors={['#4F8EF7', '#7C5CFC']} style={s.sendBtn}><T2 style={{ color: '#fff', fontSize: 18 }}>➤</T2></LinearGradient></TO2>
        </V2>
      </V2>
    </KeyboardAvoidingView>
  );
}

// ─────────────────────────────────────────────────
// src/screens/shared/ProfileScreen.js
// ─────────────────────────────────────────────────
import React3, { useState as US3 } from 'react';
import { View as V3, Text as T3, ScrollView as SV3, TextInput as TI3, TouchableOpacity as TO3, StyleSheet as SS3, Alert as AL3 } from 'react-native';
import { useAuth as UA3 } from '../../context/AuthContext';
import { updateUser } from '../../services/firebase';
import { Colors as C3, Spacing as SP3, Radius as R3 } from '../../utils/theme';
import LinearGradient2 from 'react-native-linear-gradient';

export function ProfileScreen() {
  const { profile, logout, updateProfile, demoMode } = UA3();
  const [name, setName] = US3(profile?.name || '');
  const [target, setTarget] = US3(String(profile?.target || 20));
  const [saving, setSaving] = US3(false);

  const save = async () => {
    setSaving(true);
    await updateProfile({ name, target: parseInt(target) || 20 });
    if (!demoMode) { try { await updateUser(profile?.uid, { name, target: parseInt(target) || 20 }); } catch {} }
    AL3.alert('Saved!', 'Profile updated successfully');
    setSaving(false);
  };

  const s = SS3.create({
    container: { flex: 1, backgroundColor: C3.bg },
    avatarWrap: { alignItems: 'center', padding: SP3.xxl },
    avatar: { width: 80, height: 80, borderRadius: 40, justifyContent: 'center', alignItems: 'center', marginBottom: 12 },
    avatarText: { fontSize: 32, fontWeight: '700', color: '#fff' },
    name: { fontSize: 20, fontWeight: '700', color: C3.text },
    email: { fontSize: 13, color: C3.muted, marginTop: 4 },
    roleTag: { paddingHorizontal: 12, paddingVertical: 5, borderRadius: 99, marginTop: 8, borderWidth: 1 },
    card: { marginHorizontal: SP3.lg, marginBottom: SP3.md, backgroundColor: C3.card, borderRadius: R3.lg, padding: SP3.lg, borderWidth: 1, borderColor: C3.border },
    ct: { fontSize: 14, fontWeight: '700', color: C3.text, marginBottom: 14 },
    fg: { marginBottom: 12 },
    lbl: { fontSize: 11, color: C3.muted, fontWeight: '600', letterSpacing: 0.8, marginBottom: 5 },
    inp: { backgroundColor: C3.surface, borderWidth: 1, borderColor: C3.border, borderRadius: R3.md, padding: 12, color: C3.text, fontSize: 15 },
    saveBtn: { borderRadius: R3.md, padding: 14, alignItems: 'center', marginHorizontal: SP3.lg, marginBottom: 12 },
    saveBtnText: { color: '#fff', fontWeight: '700', fontSize: 16 },
    logoutBtn: { marginHorizontal: SP3.lg, padding: 14, borderRadius: R3.md, borderWidth: 1, borderColor: C3.red, alignItems: 'center', marginBottom: 40 },
  });

  return (
    <SV3 style={s.container} showsVerticalScrollIndicator={false}>
      <V3 style={s.avatarWrap}>
        <LinearGradient2 colors={profile?.role === 'teacher' ? ['#7C5CFC', '#4F8EF7'] : ['#4F8EF7', '#7C5CFC']} style={s.avatar}>
          <T3 style={s.avatarText}>{(profile?.name || 'U').split(' ').map(w => w[0]).join('').toUpperCase().slice(0, 2)}</T3>
        </LinearGradient2>
        <T3 style={s.name}>{profile?.name}</T3>
        <T3 style={s.email}>{profile?.email}</T3>
        <V3 style={[s.roleTag, { borderColor: profile?.role === 'teacher' ? C3.accent2 : C3.accent, backgroundColor: profile?.role === 'teacher' ? '#7C5CFC15' : '#4F8EF715' }]}>
          <T3 style={{ color: profile?.role === 'teacher' ? C3.accent2 : C3.accent, fontWeight: '600', fontSize: 12 }}>{profile?.role === 'teacher' ? '👩‍🏫 Teacher' : '🎓 Student'}</T3>
        </V3>
        {demoMode && <T3 style={{ color: C3.amber, fontSize: 12, marginTop: 8, fontWeight: '600' }}>⚠️ Demo Mode — data stored locally</T3>}
      </V3>
      <V3 style={s.card}>
        <T3 style={s.ct}>Edit Profile</T3>
        <V3 style={s.fg}><T3 style={s.lbl}>DISPLAY NAME</T3><TI3 style={s.inp} value={name} onChangeText={setName} placeholderTextColor={C3.muted} /></V3>
        <V3 style={s.fg}><T3 style={s.lbl}>EXAM / SUBJECT</T3><V3 style={[s.inp, { opacity: 0.7 }]}><T3 style={{ color: C3.text }}>{profile?.examKey || profile?.subject || 'Not set'}</T3></V3></V3>
        <V3 style={s.fg}><T3 style={s.lbl}>WEEKLY TARGET (HOURS)</T3><TI3 style={s.inp} value={target} onChangeText={setTarget} keyboardType="numeric" placeholderTextColor={C3.muted} /></V3>
      </V3>
      <TO3 onPress={save} disabled={saving}><LinearGradient2 colors={['#4F8EF7', '#7C5CFC']} style={s.saveBtn}><T3 style={s.saveBtnText}>{saving ? 'Saving...' : 'Save Changes'}</T3></LinearGradient2></TO3>
      <TO3 onPress={() => AL3.alert('Sign Out', 'Are you sure?', [{ text: 'Cancel' }, { text: 'Sign Out', style: 'destructive', onPress: logout }])} style={s.logoutBtn}>
        <T3 style={{ color: C3.red, fontWeight: '700' }}>Sign Out</T3>
      </TO3>
    </SV3>
  );
}
export function NotificationsScreen() {
  return (
    <V3 style={{ flex: 1, backgroundColor: C3.bg, justifyContent: 'center', alignItems: 'center' }}>
      <T3 style={{ fontSize: 40 }}>🔔</T3>
      <T3 style={{ color: C3.text, fontSize: 18, fontWeight: '700', marginTop: 12 }}>Notifications</T3>
      <T3 style={{ color: C3.muted, marginTop: 6 }}>Firebase push notifications connect here.</T3>
    </V3>
  );
}

// ─────────────────────────────────────────────────
// src/screens/teacher/TeacherDashboardScreen.js
// ─────────────────────────────────────────────────
import React4 from 'react';
import { View as V4, Text as T4, ScrollView as SV4, TouchableOpacity as TO4, StyleSheet as SS4 } from 'react-native';
import { useData as UD4 } from '../../context/DataContext';
import { Colors as C4, Spacing as SP4, Radius as R4 } from '../../utils/theme';

export function TeacherDashboardScreen({ navigation }) {
  const { students } = UD4();
  const atRisk = students.filter(s => (s.topicsDone || 0) / Math.max(s.topicsTotal || 1, 1) < 0.2);
  const avgProg = students.length ? Math.round(students.reduce((a, s) => a + ((s.topicsDone || 0) / Math.max(s.topicsTotal || 1, 1) * 100), 0) / students.length) : 0;
  const s = SS4.create({
    container: { flex: 1, backgroundColor: C4.bg },
    title: { fontSize: 22, fontWeight: '700', color: C4.text, margin: SP4.lg },
    sg: { flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginHorizontal: SP4.lg, marginBottom: SP4.md },
    scard: { backgroundColor: C4.card, borderRadius: R4.md, padding: 14, borderWidth: 1, borderColor: C4.border, width: '47%' },
    sv: { fontSize: 22, fontWeight: '700' }, sl: { fontSize: 10, color: C4.muted, textTransform: 'uppercase', marginTop: 3 },
    card: { marginHorizontal: SP4.lg, marginBottom: SP4.md, backgroundColor: C4.card, borderRadius: R4.lg, padding: SP4.lg, borderWidth: 1, borderColor: C4.border },
    ct: { fontSize: 14, fontWeight: '700', color: C4.text, marginBottom: 12 },
    sRow: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 10, borderBottomWidth: 1, borderBottomColor: C4.border + '60' },
    sAv: { width: 36, height: 36, borderRadius: 18, backgroundColor: '#7C5CFC20', justifyContent: 'center', alignItems: 'center' },
    sName: { fontSize: 14, fontWeight: '600', color: C4.text },
    sMeta: { fontSize: 11, color: C4.muted },
    pbar: { height: 5, backgroundColor: C4.border, borderRadius: 99, overflow: 'hidden', flex: 1 },
    pfill: { height: '100%', borderRadius: 99 },
    sPct: { fontSize: 13, fontWeight: '700', width: 38, textAlign: 'right' },
  });
  const studentsList = students.length > 0 ? students : [
    { id: 's1', name: 'Ashish Kumar', subject: 'UPSC', topicsDone: 7, topicsTotal: 15, streak: 7, lastActive: 'Today' },
    { id: 's2', name: 'Meera Iyer', subject: 'UPSC', topicsDone: 8, topicsTotal: 15, streak: 4, lastActive: 'Yesterday' },
    { id: 's3', name: 'Rahul Sharma', subject: 'UPSC', topicsDone: 2, topicsTotal: 15, streak: 0, lastActive: '5d ago' },
  ];
  return (
    <SV4 style={s.container} showsVerticalScrollIndicator={false}>
      <T4 style={s.title}>👩‍🏫 Classroom Overview</T4>
      <V4 style={s.sg}>
        {[{ v: studentsList.length, l: 'Total Students', c: C4.accent }, { v: avgProg + '%', l: 'Avg Progress', c: C4.green }, { v: atRisk.length, l: 'Need Attention', c: C4.red }, { v: 0, l: 'Assignments Sent', c: C4.accent2 }].map((item, i) => (
          <V4 key={i} style={s.scard}><T4 style={[s.sv, { color: item.c }]}>{item.v}</T4><T4 style={s.sl}>{item.l}</T4></V4>
        ))}
      </V4>
      <V4 style={s.card}>
        <T4 style={s.ct}>📊 Class Progress</T4>
        {studentsList.map(st => {
          const p = Math.round((st.topicsDone || 0) / Math.max(st.topicsTotal || 1, 1) * 100);
          const c = p >= 60 ? C4.green : p >= 30 ? C4.amber : C4.red;
          return (
            <TO4 key={st.id} style={s.sRow} onPress={() => navigation.navigate('StudentDetail', { student: st })}>
              <V4 style={s.sAv}><T4 style={{ color: C4.accent2, fontWeight: '700' }}>{st.name[0]}</T4></V4>
              <V4 style={{ flex: 1 }}><T4 style={s.sName}>{st.name}</T4><T4 style={s.sMeta}>{st.subject} · {st.lastActive}</T4></V4>
              <V4 style={[s.pbar, { width: 70, flex: 0 }]}><V4 style={[s.pfill, { width: p + '%', backgroundColor: c }]} /></V4>
              <T4 style={[s.sPct, { color: c }]}>{p}%</T4>
            </TO4>
          );
        })}
      </V4>
    </SV4>
  );
}

export function StudentsScreen({ navigation }) {
  const { students } = UD4();
  const list = students.length > 0 ? students : [
    { id: 's1', name: 'Ashish Kumar', subject: 'UPSC', topicsDone: 7, topicsTotal: 15, streak: 7, avgScore: 69 },
    { id: 's2', name: 'Meera Iyer', subject: 'UPSC', topicsDone: 8, topicsTotal: 15, streak: 4, avgScore: 74 },
    { id: 's3', name: 'Karan Singh', subject: 'SSC CGL', topicsDone: 6, topicsTotal: 15, streak: 2, avgScore: 61 },
    { id: 's4', name: 'Rahul Sharma', subject: 'UPSC', topicsDone: 2, topicsTotal: 15, streak: 0, avgScore: 42 },
    { id: 's5', name: 'Priya Nair', subject: 'UPSC', topicsDone: 3, topicsTotal: 15, streak: 1, avgScore: 48 },
  ];
  return (
    <SV4 style={{ flex: 1, backgroundColor: C4.bg }} showsVerticalScrollIndicator={false}>
      <T4 style={{ fontSize: 22, fontWeight: '700', color: C4.text, margin: SP4.lg }}>👥 All Students</T4>
      {list.map(st => {
        const p = Math.round((st.topicsDone || 0) / Math.max(st.topicsTotal || 1, 1) * 100);
        const c = p >= 60 ? C4.green : p >= 30 ? C4.accent : p >= 15 ? C4.amber : C4.red;
        return (
          <TO4 key={st.id} onPress={() => navigation.navigate('StudentDetail', { student: st })}
            style={{ flexDirection: 'row', alignItems: 'center', gap: 12, marginHorizontal: SP4.lg, marginBottom: 8, backgroundColor: C4.card, borderRadius: R4.md, padding: 14, borderWidth: 1, borderColor: C4.border }}>
            <V4 style={{ width: 40, height: 40, borderRadius: 20, backgroundColor: '#7C5CFC20', justifyContent: 'center', alignItems: 'center' }}>
              <T4 style={{ color: C4.accent2, fontWeight: '700', fontSize: 16 }}>{st.name[0]}</T4>
            </V4>
            <V4 style={{ flex: 1 }}>
              <T4 style={{ fontSize: 14, fontWeight: '600', color: C4.text }}>{st.name}</T4>
              <T4 style={{ fontSize: 12, color: C4.muted }}>Streak {st.streak}🔥 · Avg {st.avgScore}%</T4>
            </V4>
            <V4 style={{ alignItems: 'flex-end' }}>
              <T4 style={{ fontSize: 16, fontWeight: '700', color: c }}>{p}%</T4>
              <V4 style={{ width: 60, height: 4, backgroundColor: C4.border, borderRadius: 99, marginTop: 4, overflow: 'hidden' }}>
                <V4 style={{ width: p + '%', height: '100%', backgroundColor: c, borderRadius: 99 }} />
              </V4>
            </V4>
          </TO4>
        );
      })}
      <V4 style={{ height: 80 }} />
    </SV4>
  );
}

export function StudentDetailScreen({ route, navigation }) {
  const { student } = route.params;
  const p = Math.round((student.topicsDone || 0) / Math.max(student.topicsTotal || 1, 1) * 100);
  return (
    <SV4 style={{ flex: 1, backgroundColor: C4.bg }} showsVerticalScrollIndicator={false}>
      <V4 style={{ alignItems: 'center', padding: SP4.xxl, backgroundColor: C4.card, borderBottomWidth: 1, borderBottomColor: C4.border }}>
        <V4 style={{ width: 70, height: 70, borderRadius: 35, backgroundColor: '#7C5CFC20', justifyContent: 'center', alignItems: 'center', marginBottom: 10 }}>
          <T4 style={{ fontSize: 28, color: C4.accent2, fontWeight: '700' }}>{student.name[0]}</T4>
        </V4>
        <T4 style={{ fontSize: 20, fontWeight: '700', color: C4.text }}>{student.name}</T4>
        <T4 style={{ fontSize: 13, color: C4.muted, marginTop: 4 }}>{student.subject}</T4>
      </V4>
      <V4 style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10, padding: SP4.lg }}>
        {[{ v: p + '%', l: 'Progress', c: C4.accent }, { v: (student.streak || 0) + '🔥', l: 'Streak', c: C4.green }, { v: (student.avgScore || 0) + '%', l: 'Avg Score', c: C4.amber }, { v: student.topicsDone || 0, l: 'Topics Done', c: C4.accent2 }].map((s, i) => (
          <V4 key={i} style={{ width: '47%', backgroundColor: C4.card, borderRadius: R4.md, padding: 14, borderWidth: 1, borderColor: C4.border }}>
            <T4 style={{ fontSize: 22, fontWeight: '700', color: s.c }}>{s.v}</T4>
            <T4 style={{ fontSize: 11, color: C4.muted, textTransform: 'uppercase', marginTop: 3 }}>{s.l}</T4>
          </V4>
        ))}
      </V4>
      <TO4 onPress={() => navigation.navigate('Conversation', { contact: { uid: student.id, name: student.name, role: 'Student' } })}
        style={{ marginHorizontal: SP4.lg }}>
        <V4 style={{ backgroundColor: C4.accent2, padding: 14, borderRadius: R4.md, alignItems: 'center' }}>
          <T4 style={{ color: '#fff', fontWeight: '700' }}>💬 Message {student.name.split(' ')[0]}</T4>
        </V4>
      </TO4>
      <V4 style={{ height: 80 }} />
    </SV4>
  );
}

export function ClassProgressScreen() {
  return (
    <V4 style={{ flex: 1, backgroundColor: C4.bg, justifyContent: 'center', alignItems: 'center' }}>
      <T4 style={{ fontSize: 40 }}>📊</T4>
      <T4 style={{ color: C4.text, fontSize: 18, fontWeight: '700', marginTop: 12 }}>Class Progress Charts</T4>
      <T4 style={{ color: C4.muted, marginTop: 6, textAlign: 'center', padding: 20 }}>Full class analytics, distribution graphs, and trend charts coming in Phase 3.</T4>
    </V4>
  );
}

export function AssignTaskScreen() {
  const [to, setTo] = React4.useState('all');
  const [title, setTitle] = React4.useState('');
  const [desc, setDesc] = React4.useState('');
  const [due, setDue] = React4.useState('');
  const { createAssignment } = UD4();
  const { profile } = UA3();
  return (
    <SV4 style={{ flex: 1, backgroundColor: C4.bg }} showsVerticalScrollIndicator={false}>
      <T4 style={{ fontSize: 22, fontWeight: '700', color: C4.text, margin: SP4.lg }}>📌 Assign Task</T4>
      <V4 style={{ marginHorizontal: SP4.lg, backgroundColor: C4.card, borderRadius: R4.lg, padding: SP4.lg, borderWidth: 1, borderColor: C4.border }}>
        {[{ lbl: 'TASK TITLE', val: title, set: setTitle, ph: 'e.g. Read Laxmikant Ch. 7' }, { lbl: 'DESCRIPTION', val: desc, set: setDesc, ph: 'Instructions...' }, { lbl: 'DUE DATE (YYYY-MM-DD)', val: due, set: setDue, ph: '2026-06-30' }].map((f, i) => (
          <V4 key={i} style={{ marginBottom: 14 }}>
            <T4 style={{ fontSize: 11, color: C4.muted, fontWeight: '600', letterSpacing: 0.8, marginBottom: 6 }}>{f.lbl}</T4>
            <TextInput style={{ backgroundColor: C4.surface, borderWidth: 1, borderColor: C4.border, borderRadius: R4.md, padding: 12, color: C4.text }} value={f.val} onChangeText={f.set} placeholder={f.ph} placeholderTextColor={C4.muted} />
          </V4>
        ))}
        <TO4 onPress={async () => { if (!title || !due) { return; } await createAssignment({ title, desc, due, priority: 'medium', from: profile?.name, fromUid: profile?.uid, toUid: to }); setTitle(''); setDesc(''); setDue(''); }}>
          <V4 style={{ backgroundColor: C4.accent2, padding: 14, borderRadius: R4.md, alignItems: 'center' }}>
            <T4 style={{ color: '#fff', fontWeight: '700', fontSize: 15 }}>Send Assignment →</T4>
          </V4>
        </TO4>
      </V4>
      <V4 style={{ height: 80 }} />
    </SV4>
  );
}

// ─────────────────────────────────────────────────
// src/screens/auth/ExamSelectorScreen.js
// ─────────────────────────────────────────────────
import React5, { useState as US5, useEffect as UE5 } from 'react';
import { View as V5, Text as T5, FlatList as FL5, TouchableOpacity as TO5, TextInput as TI5, StyleSheet as SS5, Alert as AL5 } from 'react-native';
import { EXAM_DB, EXAM_CATEGORIES } from '../../data/exams';
import { useAuth as UA5 } from '../../context/AuthContext';
import { useData as UD5 } from '../../context/DataContext';
import { updateUser as UU5 } from '../../services/firebase';
import { Colors as C5, Spacing as SP5, Radius as R5 } from '../../utils/theme';
import LinearGradient5 from 'react-native-linear-gradient';

export function ExamSelectorScreen({ navigation }) {
  const { profile, updateProfile, demoMode } = UA5();
  const { addTopic, topics } = UD5();
  const [search, setSearch] = US5('');
  const [category, setCategory] = US5('All');
  const [selected, setSelected] = US5(null);

  const exams = Object.entries(EXAM_DB).filter(([k, e]) => {
    if (category !== 'All' && e.category !== category) return false;
    if (search && !k.toLowerCase().includes(search.toLowerCase()) && !e.fullName.toLowerCase().includes(search.toLowerCase())) return false;
    return true;
  });

  const confirm = async () => {
    if (!selected) { AL5.alert('Select an exam', 'Please choose your target exam'); return; }
    const exam = EXAM_DB[selected];
    await updateProfile({ examKey: selected, subject: selected });
    if (!demoMode) { try { await UU5(profile?.uid, { examKey: selected, subject: selected }); } catch {} }
    // Load syllabus topics
    const existing = topics.map(t => t.name);
    for (const [subj, tps] of Object.entries(exam.subjects)) {
      for (const name of tps) {
        if (!existing.includes(name)) await addTopic({ subject: subj, name, status: 'pending', examKey: selected });
      }
    }
    navigation.navigate(profile?.role === 'teacher' ? 'TeacherApp' : 'StudentApp');
  };

  const s = SS5.create({
    container: { flex: 1, backgroundColor: C5.bg },
    header: { padding: SP5.xl },
    hTitle: { fontSize: 24, fontWeight: '700', color: C5.text },
    hSub: { fontSize: 13, color: C5.muted, marginTop: 4 },
    search: { marginHorizontal: SP5.lg, marginBottom: SP5.sm, backgroundColor: C5.surface, borderWidth: 1, borderColor: C5.border, borderRadius: R5.md, padding: 12, color: C5.text, fontSize: 15 },
    tabs: { paddingHorizontal: SP5.lg, paddingBottom: SP5.sm, gap: 8 },
    tab: { paddingHorizontal: 12, paddingVertical: 6, borderRadius: 99, borderWidth: 1, borderColor: C5.border, backgroundColor: C5.surface },
    tabA: { borderColor: C5.accent, backgroundColor: '#4F8EF718' },
    tabTxt: { fontSize: 12, fontWeight: '600', color: C5.muted },
    examItem: { flexDirection: 'row', alignItems: 'center', gap: 12, marginHorizontal: SP5.lg, marginBottom: 8, backgroundColor: C5.card, borderRadius: R5.md, padding: 14, borderWidth: 1, borderColor: C5.border },
    examItemSel: { borderColor: C5.accent, backgroundColor: '#4F8EF710' },
    examName: { fontSize: 15, fontWeight: '700', color: C5.text },
    examOrg: { fontSize: 12, color: C5.muted, marginTop: 2 },
    footer: { padding: SP5.lg, backgroundColor: C5.surface, borderTopWidth: 1, borderTopColor: C5.border },
    confirmBtn: { borderRadius: R5.md, padding: 16, alignItems: 'center' },
  });

  return (
    <V5 style={s.container}>
      <LinearGradient5 colors={['#0f1a35', C5.bg]} style={s.header}>
        <T5 style={{ fontSize: 14 }}>🎯</T5>
        <T5 style={s.hTitle}>Choose Your Exam</T5>
        <T5 style={s.hSub}>Select your target to load its official syllabus</T5>
      </LinearGradient5>
      <TI5 style={s.search} value={search} onChangeText={setSearch} placeholder="🔍 Search exams..." placeholderTextColor={C5.muted} />
      <FL5 horizontal showsHorizontalScrollIndicator={false} data={EXAM_CATEGORIES} keyExtractor={i => i} contentContainerStyle={s.tabs}
        renderItem={({ item }) => <TO5 style={[s.tab, category === item && s.tabA]} onPress={() => setCategory(item)}><T5 style={[s.tabTxt, category === item && { color: C5.accent }]}>{item}</T5></TO5>} />
      <FL5 data={exams} keyExtractor={([k]) => k}
        renderItem={({ item: [key, exam] }) => (
          <TO5 style={[s.examItem, selected === key && s.examItemSel]} onPress={() => setSelected(key)}>
            <V5 style={{ flex: 1 }}>
              <T5 style={s.examName}>{key}{exam.badge === 'hot' ? ' 🔥' : exam.badge === 'pop' ? ' ⭐' : ''}</T5>
              <T5 style={s.examOrg}>{exam.org} · {exam.category}</T5>
              <T5 style={{ fontSize: 11, color: C5.muted }}>{Object.values(exam.subjects).flat().length} topics · {exam.targetHours}h target</T5>
            </V5>
            {selected === key && <T5 style={{ color: C5.green, fontSize: 20 }}>✓</T5>}
          </TO5>
        )}
        showsVerticalScrollIndicator={false}
      />
      <V5 style={s.footer}>
        <TO5 onPress={confirm} disabled={!selected} style={{ opacity: selected ? 1 : 0.5 }}>
          <LinearGradient5 colors={['#4F8EF7', '#7C5CFC']} style={s.confirmBtn}>
            <T5 style={{ color: '#fff', fontWeight: '700', fontSize: 16 }}>Load Syllabus & Continue →</T5>
          </LinearGradient5>
        </TO5>
      </V5>
    </V5>
  );
}

export default ExamSelectorScreen;
