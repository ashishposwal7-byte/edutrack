# EduTrack — Complete Setup & Build Guide
## React Native Android APK

---

## 📦 What You Have

This is a complete React Native project with:
- ✅ Student app (Dashboard, Timer, AI Planner, Exam Syllabus, 1000-Hour Tracker, Test Scores, Streak, Tasks, Assignments, Chat, Progress, Profile)
- ✅ Teacher app (Classroom Overview, All Students, Assign Tasks, Chat, Profile)
- ✅ 20+ Indian exams (UPSC, SSC CGL, JEE, NEET, CAT, NDA, Banking, etc.) with full syllabus databases
- ✅ Firebase real-time sync + localStorage demo mode fallback
- ✅ Live Claude AI planner (asks Claude questions about your preparation)

---

## 🖥️ STEP 1 — Install Required Software

### On Windows:

**1. Node.js LTS**
→ Download from: https://nodejs.org
→ Install the "LTS" version (v20 or v18)
→ Verify: Open Command Prompt → type `node --version` → should show v18 or v20

**2. Java JDK 17**
→ Download from: https://www.oracle.com/java/technologies/downloads/#java17
→ Install JDK 17 (not JDK 21 — React Native 0.73 prefers 17)
→ After install, set environment variable:
  - Right-click My Computer → Properties → Advanced → Environment Variables
  - New System Variable: `JAVA_HOME` = `C:\Program Files\Java\jdk-17`
  - Add to PATH: `%JAVA_HOME%\bin`
→ Verify: `java --version`

**3. Android Studio**
→ Download from: https://developer.android.com/studio
→ During install, make sure to check:
  - ✅ Android SDK
  - ✅ Android SDK Platform
  - ✅ Android Virtual Device (for emulator)
→ After install, open Android Studio → More Actions → SDK Manager
→ Install: Android 13 (API 33) or Android 14 (API 34)
→ Set environment variable:
  - `ANDROID_HOME` = `C:\Users\YourName\AppData\Local\Android\Sdk`
  - Add to PATH: `%ANDROID_HOME%\platform-tools`

**4. Verify all setup:**
```
node --version     # v18 or v20
java --version     # 17
adb --version      # shows adb version
```

---

## 🔥 STEP 2 — Set Up Firebase (Free)

This takes 5 minutes and is required for user accounts to work.

1. Go to: https://console.firebase.google.com
2. Click "Create a project" → Name it "EduTrack" → Continue
3. Enable Google Analytics: Yes → Continue → Create project

**Add Android App:**
4. In Firebase Console → click the Android icon (</>) 
5. Android package name: `com.edutrack.app`
6. App nickname: EduTrack
7. Download `google-services.json`
8. **Replace** the `android/app/google-services.json` file in this project with the one you downloaded

**Enable Authentication:**
9. Firebase Console → Build → Authentication → Get started
10. Sign-in method → Email/Password → Enable → Save

**Enable Firestore:**
11. Firebase Console → Build → Firestore Database → Create database
12. Choose "Start in test mode" → Next → Select nearest region → Enable

**Set Firestore Rules (paste these):**
13. Firestore → Rules → Replace with:
```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /users/{userId} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
      allow read: if request.auth != null && 
        get(/databases/$(database)/documents/users/$(request.auth.uid)).data.role == 'teacher';
    }
    match /topics/{doc} {
      allow read, write: if request.auth != null && resource.data.uid == request.auth.uid;
      allow read: if request.auth != null &&
        get(/databases/$(database)/documents/users/$(request.auth.uid)).data.role == 'teacher';
    }
    match /sessions/{doc} {
      allow read, write: if request.auth != null && resource.data.uid == request.auth.uid;
    }
    match /scores/{doc} {
      allow read, write: if request.auth != null && resource.data.uid == request.auth.uid;
    }
    match /tasks/{doc} {
      allow read, write: if request.auth != null && resource.data.uid == request.auth.uid;
    }
    match /assignments/{doc} {
      allow read, write: if request.auth != null;
    }
    match /messages/{chatId}/msgs/{msgId} {
      allow read, write: if request.auth != null;
    }
  }
}
```
14. Click Publish

---

## 📁 STEP 3 — Project Setup

1. **Extract this ZIP** to a folder (e.g., `C:\Projects\EduTrack`)
2. Open Command Prompt / Terminal in that folder
3. Install dependencies:
```bash
npm install
```
This takes 2-5 minutes. You'll see lots of text — that's normal.

---

## 📱 STEP 4 — Run on Device/Emulator

### Option A: Your Android Phone (Recommended)
1. On your Android phone → Settings → About Phone → tap "Build Number" 7 times → "You are now a developer!"
2. Settings → Developer Options → Enable USB Debugging
3. Connect phone to PC via USB → Allow connection when prompted
4. In terminal:
```bash
npx react-native run-android
```

### Option B: Android Studio Emulator
1. Open Android Studio → More Actions → Virtual Device Manager
2. Create Device → Pixel 6 → Android 13 → Download → Finish
3. Start the emulator (▶ button)
4. In terminal:
```bash
npx react-native run-android
```

---

## 🏗️ STEP 5 — Build Release APK

This creates an APK file you can share or install directly.

**Create a signing key (one-time):**
```bash
cd android
keytool -genkeypair -v -storetype PKCS12 -keystore my-upload-key.keystore -alias my-key-alias -keyalg RSA -keysize 2048 -validity 10000
```
Enter a password when prompted (remember it!).

**Update `android/gradle.properties`:**
Replace `changeme123` with your actual password.

**Build the APK:**
```bash
cd android
./gradlew assembleRelease
```
(On Windows: `gradlew.bat assembleRelease`)

**Find your APK at:**
```
android/app/build/outputs/apk/release/app-release.apk
```

Send this file to anyone — they can install it directly!

---

## 🎮 STEP 6 — Test Without Firebase (Demo Mode)

You don't need Firebase to test the app. On the login screen:
- Tap **"🎓 Student Demo"** → full student app with sample UPSC data
- Tap **"👩‍🏫 Teacher Demo"** → full teacher app with sample class

Demo mode stores everything on the device (AsyncStorage). Works 100% offline.

---

## 📊 App Structure

```
EduTrack/
├── App.js                          ← Entry point
├── index.js                        ← React Native register
├── package.json                    ← Dependencies
├── babel.config.js
├── metro.config.js
├── android/                        ← Android native code
│   ├── app/
│   │   ├── build.gradle
│   │   ├── google-services.json    ← REPLACE with your Firebase file
│   │   ├── proguard-rules.pro
│   │   └── src/main/
│   │       ├── AndroidManifest.xml
│   │       ├── java/com/edutrack/
│   │       │   ├── MainActivity.java
│   │       │   └── MainApplication.java
│   │       └── res/values/
│   ├── build.gradle
│   ├── settings.gradle
│   └── gradle.properties
└── src/
    ├── context/
    │   ├── AuthContext.js          ← Login state + demo mode
    │   └── DataContext.js          ← All data + Firebase/local sync
    ├── data/
    │   └── exams.js                ← 20+ exam databases
    ├── navigation/
    │   └── AppNavigator.js         ← All routes
    ├── screens/
    │   ├── auth/                   ← Login, SignUp, ExamSelector
    │   ├── student/                ← 10+ student screens
    │   ├── teacher/                ← 5 teacher screens
    │   ├── chat/                   ← Chat + Conversation
    │   └── shared/                 ← Profile, Notifications
    ├── services/
    │   └── firebase.js             ← All Firebase calls
    └── utils/
        └── theme.js                ← Colors, fonts, spacing
```

---

## ❓ Common Errors & Fixes

**"SDK location not found"**
→ Set `ANDROID_HOME` environment variable (see Step 1)

**"JAVA_HOME is not set"**
→ Set `JAVA_HOME` to your JDK 17 path

**"Could not connect to development server"**
→ Phone and PC must be on same WiFi, OR use USB (recommended)

**"google-services.json not found"**
→ Download from Firebase Console and replace the file in `android/app/`

**"Firebase auth error"**
→ Enable Email/Password in Firebase Console → Authentication

**Build takes forever**
→ Normal on first run (downloads Gradle). Subsequent builds are fast.

**"Execution failed for task :app:processReleaseResources"**
→ Make sure `google-services.json` has the correct package name: `com.edutrack.app`

---

## 🚀 Play Store Deployment

1. Build a signed AAB: `cd android && ./gradlew bundleRelease`
2. Go to: https://play.google.com/console
3. Create new app → Upload `android/app/build/outputs/bundle/release/app-release.aab`
4. Fill in store listing (title: "EduTrack - Study Companion", description, screenshots)
5. Review & publish

---

## 📞 Need Help?

- React Native docs: https://reactnative.dev/docs/environment-setup
- Firebase setup: https://rnfirebase.io/
- Common issues: https://github.com/facebook/react-native/issues

---

*EduTrack v1.0.0 — Built with React Native 0.73 + Firebase + Claude AI*
*Supports: UPSC CSE, SSC CGL, JEE Main, NEET, NDA, CAT, CLAT, SBI PO, IBPS PO, RRB NTPC + 10 more*
